<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductDetail extends Model
{
    protected $table = 'tguy_postmeta';

    protected $fillable = ['post_id','meta_key','meta_value','created_at','updated_at'];
}
