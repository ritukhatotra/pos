<?php
namespace App\Http\Controllers;
use App\User;
use App\UserMeta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    /*
    ** Dashboard
    */
    public function dashboard() {

        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS | Dashboard";
        $data['current_url'] = url()->current();
        return view('users.home', $data);
    }

    /*
    ** New User
    */
    public function newUser() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS | Admin |Add User";
        $data['current_url'] = url()->current();
        return view('users.addUser', $data);
    }

    /*
    ** Save User
    */
    public function  saveUser(Request $request) {
        $input = $request->all();
        if(isset($input)) {
            $user = new User();
            $user->user_email = $input['email'];
            $user->user_role = 'customer';
            if($user->save()) {
                $userMeta = new UserMeta();
                $userMeta->address = $input['address'];
                $userMeta->name = $input['name'];
                $userMeta->contact_number = $input['contact_number'];
                $userMeta->user_id = $user->id;
                if($userMeta->save()){
                    $request->session()->flash('success_message', 'User added successfully!');
                    return redirect('admin/user-list');
                } else {
                    $request->session()->flash('success_message', 'User added successfully!');
                    return redirect('admin/user-list');
                }
            } else {
                $request->session()->flash('error_message', 'User not added. Please try again!!');
                return redirect('admin/add-user');
            }
        }
    }

    /*
    ** User List
    */
    public function userList(){
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS | Admin | User List";
        $data['current_url'] = url()->current();
        $data['users'] = User::where('user_role','!=', 'admin')
                        ->orderBy('ID', 'DESC')->paginate(5);
        return view('users.userList', $data);
    }

    /*
    ** Edit User
    */
    public function editUser($id=NULL) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS | Admin | User | Edit User";
        $data['current_url'] = url()->current();
        if($id == NULL){
            return redirect('admin/user-list');
        }
        $data['user'] = User::find($id);
        $data['userDetail'] = UserMeta::where('user_id', $data['user']->ID)->first();
        return view('users.editUser', $data);
    }

    /*
    ** Update User
    */
    public function updateUser(Request $request) {
        $input = $request->all();
        if(isset($input)) {
            $id = Crypt::decrypt($input['id']);
            echo "id ".$id;
            $data = array(
               'user_email' => $input['email'],
               'updated_at'=> date('Y-m-d H:i:s')
            );
            $data1 = array(
                'name' => $input['name'],
                'address' => $input['address'],
                'contact_number' => $input['contact_number'],
                'updated_at'=> date('Y-m-d H:i:s')
            );
            $userUpdate = User::where('id', $id)->update($data);
            $userDetailUpdate = UserMeta::where('user_id', $id)->update($data1);

            $request->session()->flash('success_message', 'User updated successfully!');
            return redirect('admin/user-list');
        }
    }

    /*
   ** Delete User
   */
    public function deleteUser(Request $request) {
        $id = $request->get('id');
        $dltUserMeta = UserMeta::where('user_id', $id)->delete();
        $dltUser = User::where('id',$id)->delete();
        if($dltUser != true) {
            return "error";
        }
        return "success";
    }

    /*
    ** Check existing User
    */
    public function checkUser(Request $request) {
        $email = $request->get('email');
        $user = User::where('user_email', $email)->first();
        if(isset($user)) {
            return "exist";
        }
        return "success";
    }

    /*
    ** Check existing User
    */
    public function checkUserPhone(Request $request) {
        $contact_number = $request->get('contact_number');
        $user = UserMeta::where('contact_number', $contact_number)
                ->where('contact_number','!=' , '')->first();
        if(isset($user)) {
            return "exist";
        }
        return "success";
    }
}