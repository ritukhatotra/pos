<?php
namespace App\Http\Controllers;

use App\Product;
use App\ProductDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class ProductController extends Controller
{
    /*
    ** add product
    */
    public function addProduct() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS | Admin | Add Product";
        $data['current_url'] = url()->current();
        return view('products.addProduct', $data);
    }

    /*
   ** SAVE product
   */
    public function  saveProduct(Request $request)
    {
        $input = $request->all();
        $permalinks = 'http://dev.itcorporates.com/thecomputerguywp/?post_type=product&#038;p=';
        if(isset($input)){
            $prod_name = str_replace(' ', '-', strtolower($input['title']));
            if ($request->file('prod_img')) {
                $files = $request->file('prod_img');
                for ($i = 0; $i < count($files); $i++) {
                    $name = rand().'.' . $files[$i]->getClientOriginalExtension();
                    $prodImage = new Product();
                    $prodImage->post_type = 'attachment';
                    $prodImage->post_mime_type = 'image/jpeg';
                    $prodImage->image_status = 1;
                    $prodImage->save();
                    $files[$i]->move('./public/uploads/', $name);
                    $product = new Product();
                    $product->post_title = $input['title'];
                    $product->post_type = 'product';
                    $product->post_content = $input['desc'];
                    $product->post_status = 'publish';
                    $product->post_name = $prod_name;
                    if($product->save()){
                        $arr = array('guid' => $permalinks.$product->id);
                        Product::where('ID',$product->id)->update($arr);                

                        $prodDetail = new ProductDetail();
                        $prodDetail->meta_key = '_thumbnail_id';
                        $prodDetail->meta_value = $prodImage->id;
                        $prodDetail->post_id = $product->id;
                        $prodDetail->save();

                        $prodDetailThumbnail = new ProductDetail();
                        $prodDetailThumbnail->meta_key = '_wp_attached_file';
                        $prodDetailThumbnail->meta_value = $name;
                        $prodDetailThumbnail->post_id = $prodImage->id;
                        $prodDetailThumbnail->save();

                        /* price */
                        $prodDetailPrice = new ProductDetail();
                        $prodDetailPrice->meta_key = '_price';
                        $prodDetailPrice->meta_value = $input['price'];
                        $prodDetailPrice->post_id = $product->id;
                        $prodDetailPrice->save();
                        $request->session()->flash('suc_msg', 'Product has successfully added!!');
                        return redirect('admin/all-products');

                    } else {
                        $request->session()->flash('err_msg', 'Product are not added.');
                        return redirect('admin/add-product');
                    }
                }
            }
            $request->session()->flash('err-msg', 'Product are not added.');
            return redirect('admin/add-product');
        }
    }

    /*
    ** Products List
    */
    public function allProducts() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS | Admin | Products List";
        $data['current_url'] = url()->current();
        $data['products'] = Product::where('post_type', 'product')
                            ->orderBy('ID', 'DESC')->paginate(5);
        return view('products.allProducts', $data);
    }

    /*
   ** Edit Product
   */
    public function editProduct($id=NULL) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS | Admin | Product | Edit Product";
        $data['current_url'] = url()->current();
        if($id == NULL){
            return redirect('admin/all-products');
        }
        $data['product'] = Product::find($id);
        $data['price'] = ProductDetail::where('post_id', $data['product']->ID)->where('meta_key', '_price')->first();
        $data['img_key'] = ProductDetail::where('post_id', $data['product']->ID)->where('meta_key', '_thumbnail_id')->first();
        if(isset($data['img_key'])) {
            $data['image'] = ProductDetail::where('post_id',$data['img_key']['meta_value'])
                            ->where('meta_key', '_wp_attached_file')->first();
        }
        return view('products.editProduct', $data);
    }

    /*
   ** delete photo
   */
    public function deletePhoto(Request $request){
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $imgId = $request->get('productId');
        $img = ProductDetail::where('post_id', $imgId)
                ->where('meta_key', '_wp_attached_file')->first();
        unlink("./public/uploads/".$img['meta_value']);
        $delete = ProductDetail::where('post_id', $imgId)
                  ->where('meta_key', '_wp_attached_file')->delete();
        echo $delete;
    }

    /*
    **  update product
    */
    public function updateProduct(Request $request) {
        $input = $request->all();
        $permalinks = 'http://dev.itcorporates.com/thecomputerguywp/?post_type=product&#038;p=';
        if(isset($input)) {
            $prod_name = str_replace(' ', '-', strtolower($input['title']));
            $id = Crypt::decrypt($input['id']);
            $data = array(
                'post_title' => $input['title'],
                'post_content' => $input['desc'],
                'post_status' => 'publish',
                'post_name' => $prod_name,
                'guid' => $permalinks.$id,
                'updated_at' => date('Y-m-d H:i:s')
            );
            $price = array(
                'meta_value' => $input['price']
            );

            Product::where('id', $id)->update($data);

            ProductDetail::where('post_id', $id)->where('meta_key', '_price')->update($price);

            $getImgPostId = ProductDetail::where('post_id', $id)
                ->where('meta_key', '_thumbnail_id')->first();
            /* image */
            if (isset($getImgPostId)){
                $arr = array('image_status' => 1);
                Product::where('id', $getImgPostId['meta_value'])->update($arr);
                if ($request->file('prod_img')) {
                    $files = $request->file('prod_img');
                    for ($i = 0; $i < count($files); $i++) {
                        $name = rand() . '.' . $files[$i]->getClientOriginalExtension();
                        $files[$i]->move('./public/uploads/', $name);
                        $image = new ProductDetail();
                        $image->meta_key = '_wp_attached_file';
                        $image->meta_value = $name;
                        $image->post_id = $getImgPostId['meta_value'];
                        $image->save();
                    }
                }
            }
            $request->session()->flash('suc_msg', 'Product has successfully updated!!');
            return redirect('admin/all-products');
        } else {
            $request->session()->flash('suc_msg', 'Product are not update!!');
            return redirect('admin/all-products');
        }
    }

    /*
  ** Delete Product
  */
    public function deleteProduct(Request $request) {
        $id = $request->get('id');
        $getImg = ProductDetail::where('post_id', $id)->where('meta_key','_thumbnail_id')->first();
        if(isset($getImg)){
            $img = ProductDetail::where('post_id', $getImg['meta_value'])
                    ->where('meta_key', '_wp_attached_file')->first();
            unlink("./public/uploads/".$img['meta_value']);
            ProductDetail::where('post_id', $getImg['meta_value'])->where('meta_key', '_wp_attached_file')->delete();
        }

        $priceDelete = ProductDetail::where('post_id',$id)->where('meta_key','_price')->delete();
        $productDelete = Product::where('id', $id)->delete();

        if($productDelete != true && $priceDelete != true){
            return "error";
        }
        return "success";
    }
}