<?php
namespace App\Http\Controllers;

use App\Payment;
use App\Product;
use App\ProductDetail;
use App\Sale;
use App\User;
use App\UserMeta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class SaleController extends Controller
{
    /*
    ** POS
    */
    public function pos() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sales | POS";
        $data['current_url'] = url()->current();
        $data['products'] = Product::where('post_type', 'product')
            ->orderBy('ID', 'DESC')->paginate(4);

        $data['local_path'] = './public/uploads/';
        $data['wp_filename'] = 'http://dev.itcorporates.com/thecomputerguywp/wp-content/uploads/';
        return view('sales.pos', $data);
    }

    /*
    ** daily sales report
    */
    public function dailySales() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sales | Daily Sales";
        $data['current_url'] = url()->current();
        return view('sales.dailySale', $data);
    }

    /*
    ** monthly sales report
    */
    public function monthlySales() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sales | Monthly Sales";
        $data['current_url'] = url()->current();
        return view('sales.monthlySale', $data);
    }

    /*
    ** sales report
    */
    public function salesReport() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sales | Sales Report";
        $data['current_url'] = url()->current();
        return view('sales.saleReport', $data);
    }

    /*
    ** Save User
    */
    public function  saveUser(Request $request) {
        $input = $request->all();
        if(isset($input)) {
            $user = new User();
            $user->user_email = $input['email'];
            $user->user_role = 'customer';
            if($user->save()) {
                $userMeta = new UserMeta();
                $userMeta->address = $input['address'];
                $userMeta->name = $input['name'];
                $userMeta->contact_number = $input['contact_number'];
                $userMeta->user_id = $user->id;
                if($userMeta->save()){
                    $data['email'] = $user->user_email;
                    $data['name'] = ucwords($userMeta->name);
                    $data['contact_number'] = $userMeta->contact_number;
                    $data['address'] = ucwords($userMeta->address);
                    return $data;
                }
            }
        }
    }

    /*
    ** search User
    */
    public function searchUser(Request $request) {
        $query = $request->get('query');
        $userMeta = UserMeta::where('contact_number',$query)->first();
        if(isset($userMeta)) {
            $user = User::find($userMeta['user_id']);
            $data['email'] = $user->user_email;
            $data['name'] = ucwords($userMeta['name']);
            $data['contact_number'] = $userMeta['contact_number'];
            $data['address'] = ucwords($userMeta['address']);

            $start_date = strtotime(date('Y').'-'.date('m').'-01');
            $end_date = strtotime(date('Y-m-d'));
            $prev_purchase = Payment::where('user_id',$user->ID)
                            ->where('product_service', 'new')
                            ->whereBetween('purchase_date', [$start_date, $end_date])
                            ->orderBy('id', 'DESC')->first();
            if(isset($prev_purchase)) {
                $product = Product::find($prev_purchase['product_id']);
                $purchase_product = ucfirst($product->post_title);
                $data['purc_product'] = $purchase_product;
                $data['purc_product_total'] = '$' . $prev_purchase['total'];
                $data['purc_product_date'] = date('D d, M, Y', $prev_purchase['purchase_date']);

                $data['reward_points'] = ($prev_purchase['total'] * 10) / 100;
                $data['redeem_value'] = $data['reward_points'] / 10;
            } else {
                $data['purc_product'] = 'Null';
                $data['purc_product_total'] = '0';
                $data['purc_product_date'] = 'Null';

                $data['reward_points'] = '0';
                $data['redeem_value'] = '0';
            }

            return $data;
        } else {
            return "new";
        }
    }

    /*
    ** search Product
    */
    public function searchProduct(Request $request) {
        $query = $request->get('query');
        $products = Product::where('post_type','product')
                    ->where('post_title', 'LIKE', '%'.$query.'%')->get();
        if(isset($products)) {
            foreach($products as $prod) {
                $price = ProductDetail::where('post_id', $prod['ID'])->where('meta_key', '_price')->first();
                $html = '<li>';
                $html .= '<a href="javascript:void(0)" onclick="getProduct(\''.$prod['post_title'].'\','.$prod['ID'].','.$price['meta_value'].');">'.$prod['post_title'].'</a>';
                $html .= '</li>';
                echo $html;
            }
        }
    }

    /*
    ** sale
    */
    public function sale() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sales | Sales List";
        $data['current_url'] = url()->current();
        $data['payments'] = Payment::where('product_service', 'new')->orderBy('id', 'DESC')->paginate(7);
        return view('sales.saleList', $data);
    }

    /*
   ** payment for new sale
   */
    public function newSale(Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $input = $request->all();
        if(isset($input)) {
            $price = $input['prod_price'];
            $discount = $input['redeem'];
            $subtotal = $price * $input['quantity'];
            $tax = 12 / 100;
            $productTax = $subtotal *  $tax;
            $priceBeforeDiscount = $subtotal + $productTax;
            $mrp = $priceBeforeDiscount - $discount;

            /* random slip number */
            $numbers = '0123456789';
            $numbersLength = strlen($numbers);
            $randomNumber = '';
            $length = 3;
            for ($i = 0; $i < $length; $i++) {
                $randomNumber .= $numbers[rand(0, $numbersLength - 1)];
            }

            $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charsLength = strlen($chars);
            $charString = '';
            $leng = 1;
            for ($i = 0; $i < $leng; $i++) {
                $charString .= $chars[rand(0, $charsLength - 1)];
            }
            $slip = '#'.$randomNumber.$charString;
            /* end slip number */

            $payment = new Payment();
            $payment->product_id = $input['product'];
            $payment->user_id = $input['user_id'];
            $payment->quantity = $input['quantity'];
            $payment->subtotal = $subtotal;
            $payment->total = $mrp;
            $payment->discount = $discount;
            $payment->tax = $tax;
            $payment->purchase_date = strtotime(date('Y-m-d'));
            $payment->reward_point_benefit = $input['reward_check'];
            $payment->slip_number = $slip;
            $payment->product_service = 'new';
            if($payment->save()){
                $user = User::find($payment->user_id);
                $userMeta = UserMeta::where('user_id', $payment->user_id)->first();

                $product = Product::find($payment->product_id);
                $productDetail = ProductDetail::where('post_id', $payment->product_id)
                                ->where('meta_key', '_price')->first();
                $price = $productDetail['meta_value'];

                $data['invoice'] = $payment->slip_number;
                $data['prod_name']  = $product->post_title;
                $data['prod_price'] = $price;
                $data['cust_name'] = $userMeta['name'];
                $data['cust_email'] = $user->user_email;
                $data['cust_phone'] = $userMeta['contact_number'];
                $data['cust_address'] = $userMeta['address'];
                $data['quantity'] = $payment->quantity;
                $data['reward'] = $input['reward_benefit'];
                $data['reward_check'] = $payment->reward_point_benefit;
                $data['discount'] = $payment->discount;
                $data['tax'] = $payment->tax;
                $data['date'] = $payment->purchase_date;
                $data['subtotal'] = $payment->subtotal;
                $data['total'] = $payment->total;

                return $this->invoice($data);
            } else {
                return redirect('admin/sales/pos');
            }
        }
    }

    /*
    ** New Order
    */
    public function continueSale(Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $input = $request->all();
        if(isset($input)) {
            $user = User::where('user_email', $input['posUser-email'])->first();
            $uid = $user['ID'];
            $sale = new Sale();
            $sale->user_id = $uid;
            $sale->rewards_points = $input['reward'];
            $sale->redeem_value = $input['redeem'];
            $sale->redeem_value = $input['redeem'];
            if($sale->save()) {
                $data['user_id'] = $uid;
                $data['reward'] = $sale->rewards_points;
                $data['redeem'] = $sale->redeem_value;
                return $this->orders($data);
            } else {
                return view('sales.pos');
            }
        }
    }

    public function orders($data = null){
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        if($data == null){
            $data['user_id'] = 29;
            $data['reward'] = 0;
            $data['redeem'] =0;
        }
        $data['page_title'] = "POS |  Admin | Sales | POS";
        $data['current_url'] = url()->current();
        $data['products'] = Product::where('post_type', 'product')->get();
        return view('sales.payment',$data);
    }

    /*
    ** get product price by product id
    */
    public function getProductPrice(Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $pid = $request->get('pid');
        $product = ProductDetail::where('post_id', $pid)->where('meta_key', '_price')->first();
        if(isset($product)) {
            $data['price'] = $product['meta_value'];
        } else {
            $data['price'] = 1;
        }
        return $data;
    }

    /*
    ** print
    */
    public function posPrint(Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $pid = $request->get('pid');
        $product = Product::find($pid);
        $data['product_title'] = $product->post_title;
        $productDetail = ProductDetail::where('post_id', $pid)->where('meta_key', '_price')->first();
        if(isset($productDetail)) {
            $data['price'] = $productDetail['meta_value'];
        } else {
            $data['price'] = 1;
        }
        $data['quantity'] = $request->get('quan');
        $data['reward'] = $request->get('rwd');
        $data['rewardCheck'] = $request->get('rwdCheck');
        $data['page_title'] = "POS |  Admin | Sales | POS | Print";
        $data['current_url'] = url()->current();
        return view('sales.print', $data);
    }

    /*
    ** invoice
    */
    public function invoice($data = NULL) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Invoice";
        $data['current_url'] = url()->current();
        return view('sales.invoice', $data);
    }

    /*
    ** repair service
    */
    public function repairService(Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $input = $request->all();
        if(isset($input)) {
            $payment = new Payment();
            $payment->product_id = $input['service'];
            $payment->service_price = $input['service_price'];
            $payment->repair_part = $input['repair_part'];
            $payment->user_id = $input['user_id'];
            $payment->slip_number = $input['slip'];
            $payment->product_service = 'repair';
            $payment->status = $input['status'];
            $payment->purchase_date = strtotime(date('Y-m-d'));
            if($payment->save()){
                $user = User::find($payment->user_id);
                $userMeta = UserMeta::where('user_id', $payment->user_id)->first();

                $product = Product::find($payment->product_id);

                $data['invoice'] = $payment->slip_number;
                $data['service_name']  = $product->post_title;
                $data['cust_name'] = $userMeta['name'];
                $data['cust_email'] = $user->user_email;
                $data['cust_phone'] = $userMeta['contact_number'];
                $data['cust_address'] = $userMeta['address'];
                $data['date'] = $payment->purchase_date;
                $data['price'] = $payment->service_price;
                $data['status'] = $payment->service_price;
                $data['repair_part'] = $payment->repair_part;

                return $this->repairInvoice($data);
            } else {
                return redirect('admin/sales/pos');
            }
        }
    }

    /*
    ** repair invoice
    */
    public function repairInvoice($data = NULL) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Invoice";
        $data['current_url'] = url()->current();
        return view('sales.repairInvoice', $data);
    }

    /*
    ** tracking
    */
    public function repairTracking($data = NULL) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Repair Tracking";
        $data['current_url'] = url()->current();
        $data['payments'] = Payment::where('product_service', 'repair')->orderBy('id','DESC')->paginate(5);
        return view('sales.tracking', $data);
    }

    /*
    ** sales invoices
    */
    public function saleInvoices() {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sale | Invoice";
        $data['current_url'] = url()->current();
        $data['payments'] = Payment::where('product_service', 'new')->orderBy('id', 'DESC')->paginate(7);

        return view('sales.newsale.invoice', $data);
    }

    /*
    ** sales invoices
    */
    public function generateInvoice($id=null, Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sale | Invoice";
        $data['current_url'] = url()->current();

        $id = $request->get('id');
        $payment = Payment::find($id);
        $user = User::find($payment->user_id);
        $userMeta = UserMeta::where('user_id', $payment->user_id)->first();
        $product = Product::find($payment->product_id);
        $productDetail = ProductDetail::where('post_id', $payment->product_id)
            ->where('meta_key', '_price')->first();
        $price = $productDetail['meta_value'];
        $sale = Sale::where('user_id', $payment->user_id)->orderBy('id', 'DESC')->first();

        $data['invoice'] = $payment->slip_number;
        $data['prod_name']  = $product->post_title;
        $data['prod_price'] = $price;
        $data['cust_name'] = $userMeta['name'];
        $data['cust_email'] = $user->user_email;
        $data['cust_phone'] = $userMeta['contact_number'];
        $data['cust_address'] = $userMeta['address'];
        $data['quantity'] = $payment->quantity;
        $data['reward'] = $sale['rewards_points'];
        $data['reward_check'] = $payment->reward_point_benefit;
        $data['discount'] = $payment->discount;
        $data['tax'] = $payment->tax;
        $data['date'] = $payment->purchase_date;
        $data['subtotal'] = $payment->subtotal;
        $data['total'] = $payment->total;

        return view('sales.newsale.generateInvoice', $data);
    }

    /*
    ** repair invoices
    */
    public function repairBill($id=null, Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sale | Invoice";
        $data['current_url'] = url()->current();

        $id = $request->get('id');
        $payment = Payment::find($id);
        $user = User::find($payment->user_id);
        $userMeta = UserMeta::where('user_id', $payment->user_id)->first();
        $product = Product::find($payment->product_id);

        $data['invoice'] = $payment->slip_number;
        $data['service_name']  = $product->post_title;
        $data['cust_name'] = $userMeta['name'];
        $data['cust_email'] = $user->user_email;
        $data['cust_phone'] = $userMeta['contact_number'];
        $data['cust_address'] = $userMeta['address'];
        $data['date'] = $payment->purchase_date;
        $data['price'] = $payment->service_price;
        $data['status'] = $payment->service_price;
        $data['repair_part'] = $payment->repair_part;

        return view('sales.repair.generateInvoice', $data);
    }

    /*
    ** billing product + services
    */
    public function allBilling($id=null, Request $request) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Sale | Invoice";
        $data['current_url'] = url()->current();

        $id = $request->get('id');
        $payment = Payment::find($id);
        $user = User::find($payment->user_id);
        $userMeta = UserMeta::where('user_id', $payment->user_id)->first();
        $product = Product::find($payment->product_id);

        $data['invoice'] = $payment->slip_number;
        $data['service_name']  = $product->post_title;
        $data['cust_name'] = $userMeta['name'];
        $data['cust_email'] = $user->user_email;
        $data['cust_phone'] = $userMeta['contact_number'];
        $data['cust_address'] = $userMeta['address'];
        $data['date'] = $payment->purchase_date;
        $data['price'] = $payment->service_price;
        $data['status'] = $payment->service_price;
        $data['repair_part'] = $payment->repair_part;

        return view('sales.repair.generateInvoice', $data);
    }

    /*
    ** service Invoice
    */
    public function serviceInvoice($data = NULL) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Service Invoice";
        $data['current_url'] = url()->current();
        $data['payments'] = Payment::where('product_service', 'repair')->orderBy('id','DESC')->paginate(5);
        return view('sales.repair.invoice', $data);
    }

    /*
    ** edit repair Service
    */
    public function editService($id = NULL) {
        if(session('id') == ''){
            return redirect('admin/signin');
        }

        $data['page_title'] = "POS |  Admin | Service | Edit";
        $data['current_url'] = url()->current();

        if($id == NULL) {
            return redirect('admin/pos/repair-tracking');
        }

        $data['payment'] = Payment::find($id);
        $data['user'] = User::find($data['payment']->user_id);
        $data['userMeta'] = UserMeta::where('user_id', $data['user']->ID)->first();
        $data['product'] = Product::find($data['payment']->product_id);
        return view('sales.editService', $data);
    }

    /*
    ** update repair Service
    */
    public function updateService(Request $request) {
        $input = $request->all();
        $arr = array('status' => $input['status'],
                     'repair_part' => $input['fault'],
                     'service_price' => $input['price'],
                     );

        $update = Payment::where('id', $input['id'])->update($arr);
        if($update) {
            return redirect('admin/pos/repair-tracking');
        } else {
            $data['payment'] = Payment::find($input['id']);
            $data['user'] = User::find($data['payment']->user_id);
            $data['userMeta'] = UserMeta::where('user_id', $data['user']->ID)->first();
            $data['product'] = Product::find($data['payment']->product_id);
            $request->session()->flash('msg', 'Service editing failed!');
            return view('sales.editService', $data);
        }
    }

}