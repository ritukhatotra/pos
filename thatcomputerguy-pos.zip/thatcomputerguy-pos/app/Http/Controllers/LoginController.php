<?php
namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    /*
    ** admin Login
    */
    public function signin() {
        $data['page_title'] = "POS | Admin Signin";
        $data['current_url'] = url()->current();
        return view('auth.login', $data);
    }

    /*
    ** post Login data
    */
    public function postSignin(Request $request) {
       $input = $request->all();
       if(isset($input)) {
           $login = User::where('user_email',$input['email'])
                    ->where('user_pass',md5($input['password']))
                    ->where('user_role','admin')->first();
           if(isset($login)) {
               $user = array(
                        'id' => $login['ID'],
                        'email' => $login['user_email'],
                    );

               $request->session()->put($user);
               return redirect('admin/dashboard');
           } else {
               $request->session()->flash('err_msg', 'Wrong email / password.');
               return redirect('admin/signin');
           }
       }
    }

    /*
    **  Logout
    */
    public function logout() {
        Auth::logout();
        Session::flush();
        return Redirect::to('admin/signin');
    }
}