<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class UserMeta extends Model
{
    protected $table = 'tguy_usermeta';
    protected $fillable = ['name','address','contact_number','created_at','updated_at','user_id','profile_photo'];
}
