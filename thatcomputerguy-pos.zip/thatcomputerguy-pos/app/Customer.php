<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model {
	/**
    * The table associated with the model.
    *
    * @var string
    */
    protected $table = 'tguy_customers';

    /**
    * The attributes that are mass assignable.
    *
    * @var array
    */
    protected $fillable = ['first_name', 'last_name', 'email', 'password', 'contact_number', 'address', 'created_at', 'updated_at', 'users_id']; 

    /**
	* Get the validation rules that apply to the request.
	*
	* @return array
	*/
	public function rules()
	{
	    return [
	    	'first_name' => 'required',
	        'email' => 'required|unique:tguy_customers',
	        'contact_number' => 'required|unique:tguy_customers',
	        'address' => 'required'
	    ];
	}
}
?>