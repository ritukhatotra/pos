<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'tguy_posts';

    protected $fillable = ['post_title','post_type','post_content','post_mime_type','created_at','updated_at',
                            'post_status','post_name','guid','image_status'];
}
