<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    protected $table = 'tguy_sales';
    protected $fillable = ['user_id', 'rewards_points', 'redeem_value'];

}