<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $table = 'tguy_users';
    protected $fillable =['user_login','user_email','user_pass','user_role','created_at','updated_at', 'email_token', 'token_expiry'];
    protected $hidden = ['password', 'remember_token'];
}
