<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $table = 'tguy_payments';

    protected $fillable = ['product_id', 'service_price', 'user_id', 'quantity', 'total', 'purchase_date',
                           'slip_number', 'reward_point_benefit', 'subtotal', 'tax', 'discount',
                           'product_service', 'status','created_at', 'updated_at', 'repair_part'];
}