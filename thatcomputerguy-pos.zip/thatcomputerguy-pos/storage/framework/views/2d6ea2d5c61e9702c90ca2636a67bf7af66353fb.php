<?php
$extractName = explode("@",session('email'));
$username = $extractName[0];
?>
<div class="navbar nav_title" style="border: 0;">
    <a href="#" class="site_title">
        <span>That Computer</span>
        <img src="<?php echo e(asset('public/images/logo.png')); ?>" alt=""/>
    </a>
</div>
<div class="clearfix"></div>
<div class="profile clearfix">
    <div class="profile_pic">
        <img src="<?php echo e(asset('public/images/img.jpg')); ?>" alt="..." class="img-circle profile_img"/>
    </div>
    <div class="profile_info">
        <span>Welcome,</span>
        <h2><?php echo e(ucfirst($username)); ?></h2>
    </div>
</div>
<br />