<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" href="<?php echo e(asset('public/images/fav-icon.png')); ?>" type="image/ico" />
		<title><?php echo e($page_title); ?>></title>
	    <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</head>
	<body>
		<div class="container">
		    <header class="row">
		        <?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    </header>
		    <div id="main" class="row">
	            <?php echo $__env->yieldContent('content'); ?>
		    </div>
		</div>
	</body>
</html>

