<!doctype html>
<html>
<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="nav-md that-computer-guy">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('common.top_navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<script src="<?php echo e(asset('public/js/jquery.min.js')); ?>"></script>
<script src='<?php echo e(asset('public/js/select2.min.js')); ?>' type='text/javascript'></script>
<script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/print.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/sales/sale.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jquery.validate.min.js')); ?>"></script>
<?php if($current_url == env('APP_URL').'admin/sales/pos'): ?>
    <script src="<?php echo e(asset('public/js/user/user.js')); ?>"></script>
<?php endif; ?>
</body>
</html>

