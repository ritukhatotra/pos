<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo e($page_title); ?></title>
    <link rel="icon" href="<?php echo e(asset('public/images/fav-icon.png')); ?>" type="image/ico" />
    <link href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/css/custom.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/css/bootstrap3-wysihtml5.min.css')); ?>" rel="stylesheet" type="text/css">
</head>