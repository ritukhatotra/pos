<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-9 col-xs-12">
                <div class="row">
                    <h1>Repair Tracking</h1>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12">
                <div class="row">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="#">Admin</a></li>
                        <li class="breadcrumb-item active">Repair Tracking</li>
                    </ol>
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="row">
                    <div class="panel panel-primary panel-primary-custom">
                        <div class="panel-heading">
                            <h3 class="panel-title">Services</h3>
                        </div>
                        <div class="table-list-user">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sr No.</th>
                                        <th scope="col">Slip No.</th>
                                        <th scope="col">Customer Name</th>
                                        <th scope="col">Customer Email</th>
                                        <th scope="col">Customer Phone</th>
                                        <th scope="col">Service Name</th>
                                        <th scope="col">Damaged Part</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Status </th>
                                        <th scope="col">Total </th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <?php
                                $i = 1;
                                ?>
                                <tbody>
                                    <?php if(isset($payments)): ?>
                                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $user = \App\User::find($payment['user_id']);
                                            $userDetail = \App\UserMeta::where('user_id', $payment['user_id'])->first();
                                            $product = \App\Product::find($payment['product_id']);
                                            $timestamp = strtotime($payment['created_at']);
                                            $date = date('D d, M, Y', $timestamp);
                                            ?>
                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e($payment['slip_number']); ?></td>
                                                <td><?php echo e(ucwords($userDetail['name'])); ?></td>
                                                <td><?php echo e(ucfirst($user->user_email)); ?></td>
                                                <td><?php echo e($userDetail['contact_number']); ?></td>
                                                <td><?php echo e($product['post_title']); ?></td>
                                                <td><?php echo e($payment['repair_part']); ?></td>
                                                <td>$<?php echo e($payment['service_price']); ?></td>
                                                <td><?php echo e($payment['status']); ?></td>
                                                <td>$<?php echo e($payment['service_price']); ?></td>
                                                <td><?php echo e($date); ?></td>
                                                <td width="10%">
                                                    <a href="<?php echo e(url('admin/service/edit/'.$payment['id'])); ?>" data-toggle="tooltip" title="Edit"><i class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(url('repair-bill?id='.$payment['id'])); ?>" data-toggle="tooltip" title="Generate Invoice" target="_blank"><i class="fa fa-print"></i></a>
                                                </td>
                                            </tr>
                                            <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7">No Records.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('sales.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>