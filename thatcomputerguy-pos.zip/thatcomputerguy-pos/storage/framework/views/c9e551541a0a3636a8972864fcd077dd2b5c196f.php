<?php $__env->startSection('content'); ?>
	<div class="container">
		<?php $i = 1; ?>
		<table width="100%">
			<th>Sr. No.</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Email</th>
			<th>Contact</th>
			<th>Address</th>
			<th>Action</th>
			<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i); ?></td>
					<td><?php echo e($customer['first_name']); ?></td>
					<td><?php echo e($customer['last_name']); ?></td>
					<td><?php echo e($customer['email']); ?></td>
					<td><?php echo e($customer['contact_number']); ?></td>
					<td><?php echo e($customer['address']); ?></td>
					<td>Edit</td>
				</tr>
				 <?php $i++; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customers.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>