<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-5 col-xs-12">
                <div class="row">
                    <div class="panel panel-primary panel-primary-custom">
                        <div class="panel-heading">
                            <h3 class="panel-title">Please fill in the information below</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="select">
                                    <input name="search-user" id="search-user" placeholder="Search user by phone number" value="" class="form-control" type="text" autocomplete="off">
                                    <span class="fa fa-search src-user"></span>
                                    <a href="#" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i></a>
                                </div>
                            </div>
                            <div class="display-user hide-user form-group">
                                <div class="form-group">
                                    <input type="text" name="posUser-name" id="posUser-name" value="" class="form-control" />
                                </div>
                                <div class="form-group">
                                    <input type="text" name="posUser-email" id="posUser-email" value="" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" id="search-prod" name="prod-name" placeholder="Search product by name" value="" class="form-control" autocomplete="off"/>
                            </div>
                            <ul id="product-list" class="hide-user"></ul>
                            <div class="panel panel-primary panel-primary-custom product-detail pos-table">
                                <div class="table-list-user">
                                    <table class="table" id="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Product</th>
                                                <th scope="col">Price</th>
                                                <th scope="col">Qty</th>
                                                <th scope="col">Subtotal </th>
                                                <th scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="panel panel-primary panel-primary-custom product-detail total-cal">
                                    <div class="table-list-user">
                                        <table class="table" id="table2">
                                            <tbody>
                                                <tr>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <form id="payment" method="post" action="<?php echo e(url('payment')); ?>">
                                    <div class="panel panel-primary panel-primary-custom product-detail btns-table">
                                        <div class="table-list-user">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                                            <input type="hidden" id="uemail" name="uemail"/>
                                            <input type="hidden" id="pid" name="pid"/>
                                            <input type="hidden" id="quantity" name="quantity"/>
                                            <input type="hidden" id="total" name="total"/>
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <td><button type="button" class="purple-bg">Print Order</button></td>
                                                        <td><button type="submit" class="green-bg">Payment</button></td>
                                                        <td><button type="button" class="red-bg">Cancel</button></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-7 col-xs-12 product_col">
                <div class="panel panel-primary panel-primary-custom product-selection">
                    <div class="panel-body">
                        <?php if(isset($products)): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $imgKey = \App\ProductDetail::where('post_id', $prod['ID'])->where('meta_key', '_thumbnail_id')->first();
                                if(isset($imgKey)) {
                                    $imgVal =   \App\ProductDetail::where('post_id', $imgKey['meta_value'])->where('meta_key', '_wp_attached_file')->first();
                                    $filename = $local_path.$imgVal['meta_value'];
                                }
                                ?>
                                <div class="col-sm-3 col-xs-6">
                                    <div class="product-clm">
                                        <div class="product-img"><?php if(isset($imgKey)): ?>
                                                <?php if(file_exists($filename)): ?>
                                                    <img src="<?php echo e(asset('public/uploads/'.$imgVal['meta_value'])); ?>" height="80px" />
                                                <?php else: ?>
                                                    <img src="<?php echo e($wp_filename.$imgVal['meta_value']); ?>" height="80px" />
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                        <h4><?php echo e(ucwords($prod['post_title'])); ?></h4>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <div class="bottom-clm">
                            <?php if(isset($products)): ?>
                                <div class="paginatio-row pos-pagination">
                                    <?php echo e($products->links()); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- popup section -->
    <!-- Pop up Plus icon-->
    <div class="modal fade pos-modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="panel panel-primary panel-primary-custom">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Please fill in the information below</h3>
                                </div>
                                <div class="panel-body">
                                    <form id="add-user-form-pos" method="post">
                                        <div class="form-group">
                                            <label>Full Name <span class="mandatory-field-icon">*</span></label>
                                            <input type="text" id="name" name="name" placeholder="Enter Full Name" value="" class="form-control" autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label>Email <span class="mandatory-field-icon">*</span></label>
                                            <input type="email" id="email" name="email" placeholder="Enter Email" value="" class="form-control" autocomplete="off">
                                            <span id="email-msg"></span>
                                        </div>
                                        <div class="form-group">
                                            <label>Contact Number <span class="mandatory-field-icon">*</span></label>
                                            <input type="tel" name="contact_number" placeholder="Enter Contact Number" value="" class="form-control" autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label>Address <span class="mandatory-field-icon">*</span></label>
                                            <textarea name="address" placeholder="Enter Address..." class="form-control" autocomplete="off"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" value="Submit" class="full-width">
                                            <input type="submit" value="Close" data-dismiss="modal" class="full-width close-btn">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('sales.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>