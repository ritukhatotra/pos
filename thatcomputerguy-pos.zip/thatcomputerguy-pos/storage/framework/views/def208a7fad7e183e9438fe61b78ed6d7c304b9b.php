<?php $__env->startSection('content'); ?>
	<div class="container">
		<form id="add-customer-form" action="<?php echo e(url('customer/save')); ?>" method="post">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
			<div class="form-group">
				<input type="text" name="fname" placeholder="Enter first name" />
			</div>
			<div class="form-group">
				<input type="text" name="lname" placeholder="Enter last name" />
			</div>
			<div class="form-group">
				<input type="text" name="email" placeholder="Enter email" />
			</div>
			<div class="form-group">
				<input type="text" name="contact" placeholder="Enter contact number" />
			</div>
			<div class="form-group">
				<textarea name="address" placeholder="Enter address"></textarea>
			</div>
			<div class="form-group">
				<input type="submit" name="submit" value="Save">
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
	jQuery(function() {
		jQuery("#add-customer-form").validate({
			rules: {
				fname: "required",
				email: {
					required: true,
					email: true
				},
				address: {
					required:true
				},
				contact: {
					required: true,
					number: true
				}
			},
			submitHandler: function(form) {
				form.submit();
			}
		});
	});
</script>
<?php echo $__env->make('customers.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>