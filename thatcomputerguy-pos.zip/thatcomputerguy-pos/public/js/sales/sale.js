// var BASE_URL = "http://localhost/pos-new/";
var BASE_URL = "http://dev.itcorporates.com/theComputerGuy_pos/";

$(document).ready(function (){
    $("#pos-product").select2();
    $("#repair-service").select2();
});

/* search user on press enter key */
$('#search-user').keypress(function (e) {
    var key = e.which;
    if(key == 13) {
        var input = $(this).val();

        if (!$.isNumeric(input)) {
            alert('Only numbers allow!');
        } else if (input === '') {
            alert('Enter phone number');
        } else if (input.length < 10) {
            alert('Phone number should 10 digit or above!');
        } else {
            $.ajax({
                type: 'POST',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
                url: BASE_URL + 'admin/sales/searchUser',
                data: {query: input},
                success: function (res) {
                    if (res === 'new') {
                        $("#contact_number").val(input);
                        $("#newUserModal").modal('show');
                    } else {
                        // console.log(res);
                        $(".display-user").removeClass('hide-user');
                        $(".select").addClass('hide-user');
                        $("#posUser-name").val(res.name);
                        $("#posUser-name").val(res.name);
                        $("#posUser-email").val(res.email);
                        $("#posUser-phone").val(res.contact_number);
                        $("#posUser-address").val(res.address);
                        $("td#c1").html(res.purc_product);
                        $("td#c2").html(res.purc_product_total);
                        $("td#c3").html(res.purc_product_date);
                        $("#reward").attr('readonly', true);
                        $("#redeem").attr('readonly', true);
                        $("#reward").val(res.reward_points);
                        $("#redeem").val(res.redeem_value);
                        $('.continue-pos').prop("disabled", false)
                    }
                }
            });
        }
    }
});

/* search user on click go button */
$("a#search-go").on('click', function(){
    var input = $("#search-user").val();

    if(!$.isNumeric(input)){
        alert('Only numbers allow!');
    } else if(input === '') {
        alert('Enter phone number');
    } else if(input.length < 10) {
        alert('Allow 10 digit or above 10');
    } else {
        $.ajax({
            type : 'POST',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
            url  : BASE_URL+'admin/sales/searchUser',
            data : {query : input},
            success: function(res) {
                if(res === 'new') {
                    $("#contact_number").val(input);
                    $("#newUserModal").modal('show');
                } else {
                    // console.log(res);
                    $(".display-user").removeClass('hide-user');
                    $(".select").addClass('hide-user');
                    $("#posUser-name").val(res.name);
                    $("#posUser-name").val(res.name);
                    $("#posUser-email").val(res.email);
                    $("#posUser-phone").val(res.contact_number);
                    $("#posUser-address").val(res.address);
                    $("td#c1").html(res.purc_product);
                    $("td#c2").html(res.purc_product_total);
                    $("td#c3").html(res.purc_product_date);
                    $("#reward").attr('readonly', true);
                    $("#redeem").attr('readonly', true);
                    $("#reward").val(res.reward_points);
                    $("#redeem").val(res.redeem_value);
                    $('.continue-pos').prop("disabled", false)
                }
            }
        });
    }
});

/* search product */
/* search product on press enter key */
$('#search-prod').on('keyup', function (e) {
    var input = $(this).val();
    if(input.length >= 1) {
        var input = $(this).val();
        $.ajax({
            type : 'POST',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
            url  : BASE_URL+'admin/sales/searchProduct',
            data : {query : input},
            success: function(res) {
                $("#product-list").removeClass('hide-user');
                $("#product-list").html(res);
            }
        });
    } else {
        $("#product-list").addClass('hide-user');
        $("#product-list").html('');
    }
});
i = 0;
function getProduct(name, id, price){
    qnty_id = 'qnty_' + id;
    $("#product-list").addClass('hide-user');
    $("#product-list").html('');
    $("#search-prod").val(name);
    if ($('table#table').find('tr#prod_'+id).length > 0) {
        i++;
        subtotal = price * i;
        var html = '<td>' + name + '</td>' +
            '<td>$' + price + '</td>' +
            '<td><input type="text" id=' + qnty_id + ' name="price" value='+i+' class="form-control qty-field"/></td>' +
            '<td>$<span class="subtotal">'+subtotal+'</span></td>' +
            '<td><a href="#"><i class="fa fa-trash"></i></a></td>';
        $('tr#prod_' + id).html(html);
    } else {
        i=1;
        subtotal = price * i;
        var html = '<tr id="prod_' + id + '">' +
            '<td>' + name + '</td>' +
            '<td>$' + price + '</td>' +
            '<td><input type="text" id=' + qnty_id + ' name="price" value='+i+' class="form-control qty-field"/></td>' +
            '<td>$<span class="subtotal">'+subtotal+'</span></td>' +
            '<td><a href="#"><i class="fa fa-trash"></i></a></td>' +
            '</tr>';
        $("#table tbody").append(html);
        i++;
    }
    var sum = 0, total=0;
    $(".qty-field").each(function(){
        sum += +$(this).val();
    });
    $(".subtotal").each(function(){
        total += +$(this).html();
    });
    var total_html = '<td align="left">Total Items</td>'+
                        '<td>'+sum+'</td>' +
                        '<td align="left">Total</td>'+
                        '<td>$'+total+'</td>';
    $("#table2 tbody tr").html(total_html);
    $("#total").val(total);
    $("#pid").val(id);
    $("#quantity").val(sum);
}

/* form validation on new user */
$(function() {
    $("#add-user-form-pos").validate({
        rules: {
            name: "required",
            email: {
                required: true,
                email: true
            },
            address: {
                required:true
            },
            contact_number: {
                required: true,
                number: true
            }
        },
        submitHandler: function(form) {
            $.ajax({
                type : 'POST',
                url  : BASE_URL+'admin/sales/add-user',
                data : $('form').serialize(),
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
                success: function(res) {
                    console.log(res);
                    $("#newUserModal").modal('hide');
                    $(".display-user").removeClass('hide-user');
                    $(".select").addClass('hide-user');
                    $("#posUser-name").val(res.name);
                    $("#posUser-name").val(res.name);
                    $("#posUser-email").val(res.email);
                    $("#posUser-phone").val(res.contact_number);
                    $("#posUser-address").val(res.address);
                    $("td#c1").html('Null');
                    $("td#c2").html('0');
                    $("td#c3").html('Null');
                    $("#reward").attr('readonly', true);
                    $("#redeem").attr('readonly', true);
                    $("#reward").val('0');
                    $("#redeem").val('0');
                    $('.continue-pos').prop("disabled", false)
                }
            });
        }
    });
});

/* continue new sale */
$(function() {
    $("#new-sale").validate({
        rules: {
            product: "required",
            prod_price: "required",
            quantity: "required",
            reward_check: "required"
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});

$("#pos-product").on('change', function(){
    var pid = $("#pos-product option:selected").val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'admin/sales/getProductPrice',
        data : {pid : pid},
        success: function(res) {
           $('#prod_price').val(res.price);
        }
    });
});

/* preview */
$("#previewDetail").on('click', function(){
    $("#previewModal").modal('show');
    var product = $("#pos-product option:selected").text();
    var price = $("#prod_price").val();
    var quantity = $("#quantity").val();
    var reward = $("#quantity").val();
    var reward_check = $("input[name='reward_check']:checked").val();
    $("td#col1").html(product);
    $("td#col2").html(price);
    $("td#col3").html(quantity);
    $("td#col4").html(reward);
    $("td#col5").html(reward_check);
});

/* print pos */
function printPos() {
    var pid = $("#pos-product option:selected").val();
    var reward = $("#quantity").val();
    var quantity = $("#quantity").val();
    var reward_check = $("input[name='reward_check']:checked").val();
    var url = BASE_URL+'admin/sales/pos/print?pid='+pid+'&rwd='+reward+'&rwdCheck='+reward_check+'&quan='+quantity;

    window.open(url, '_blank');
}

/* print invoice */
$("#print-btn").on('click', function(){
    $("#invoice").print();
});

$(function() {
    $("#repair-form").validate({
        rules: {
            service: "required",
            repair_part: "required",
            service_price: "required",
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});

$(function() {
    $("#edit-service-form").validate({
        rules: {
            price: "required",
            fault: "required",
            status: "required",
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});

