// var BASE_URL = "http://localhost/pos-new/";
var BASE_URL = "http://dev.itcorporates.com/theComputerGuy_pos/";

$('.textarea').wysihtml5();

/* validation on add product */
jQuery(function() {
    jQuery("#product-form").validate({
        rules: {
            title: "required",
            price: {
                required: true
            },
            desc: {
                required:true
            },
            "prod_img[]": "required"
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});

/* validation on edit product */
jQuery(function() {
    jQuery("#edit-product-form").validate({
        rules: {
            title: "required",
            price: {
                required: true
            },
            desc: {
                required:true
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});
/* delete product image */
function deleteimage(productId)
{
    var check = confirm ("Are you sure you want to delete this image?");
    if (check)
    {
        $.ajax({
            type: "GET",
            url: BASE_URL+"admin/deletePhoto",
            data: "productId="+productId,
            success: function (response) {
                if (response === 1) {
                    $(".imagelocation"+productId).remove(".imagelocation"+productId);
                }
            }
        });
    }
}

/* DELETE PRODUCT CODE */
function deleteProd(id) {
    if(!confirm('Are you sure want delete this product?')){
        return false;
    }
    $.ajax({
        type : 'GET',
        url  : BASE_URL+'admin/deleteProduct',
        data : {id : id},
        success: function(res) {
            if(res == 'success') {
                $('#delete-msg').addClass('alert alert-success pull-left green-bg');
                $('#delete-msg').html('Product has successfully deleted!!').delay(3000).fadeOut("slow");
                $("#record-" + id).fadeOut("slow");
            } else {
                $('#delete-msg').addClass('alert alert-danger pull-left');
                $('#delete-msg').html('Product not delete!!').delay(3000).fadeOut("slow");
            }
        },
        error:function (err){
            $('#delete-msg').addClass('alert alert-danger pull-left');
            $('#delete-msg').html('Product not delete!!').delay(3000).fadeOut("slow");

        }
    });
}
