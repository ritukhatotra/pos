 // var BASE_URL = "http://localhost/pos-new/";
var BASE_URL = "http://dev.itcorporates.com/theComputerGuy_pos/";

/* form validation on add user or edit user */
var $ADDCUSTOMER = '#add-user-form';
jQuery(function() {
    jQuery($ADDCUSTOMER).validate({
        rules: {
            name: "required",
            email: {
                required: true,
                email: true
            },
            address: {
                required:true
            },
            contact_number: {
                required: true,
                number: true
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});

$('#success-msg').delay(3000).fadeOut("slow");

/* DELETE USER CODE */
function deleteUser(id) {
    if(!confirm('Are you sure want delete this user?')){
        return false;
    }
    $.ajax({
        type : 'GET',
        url  : BASE_URL+'admin/deleteUser',
        data : {id : id},
        success: function(res) {
            if(res == 'success') {
                $('#delete-msg').addClass('alert alert-success pull-left green-bg');
                $('#delete-msg').html('User have successfully deleted!!').delay(3000).fadeOut("slow");
                $("#record-" + id).fadeOut("slow");
            } else {
                $('#delete-msg').addClass('alert alert-danger pull-left');
                $('#delete-msg').html('User not delete!!').delay(3000).fadeOut("slow");
            }
        },
        error:function (err){
            $('#delete-msg').addClass('alert alert-danger pull-left');
            $('#delete-msg').html('User not delete!!').delay(3000).fadeOut("slow");

        }
    });
}

/* check duplicate user */
$("#email").blur(function(){
    var email = $(this).val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'admin/checkUser',
        data : {email : email},
        success: function(res) {
            if(res === 'exist') {
                $('#email-msg').html('Email already exist.');
            } else {
                $('#email-msg').html('');
            }
        }
    });
});

$("#contact_number").blur(function(){
    var contact_number = $(this).val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'admin/checkUserPhone',
        data : {contact_number : contact_number},
        success: function(res) {
            if(res === 'exist') {
                $('#contact-msg').html('Phone number already exist.');
            } else {
                $('#contact-msg').html('');
            }
        }
    });
});

/* login validation */
$(function() {
    $("#login-form").validate({
        rules: {
            email: "required",
            password: "required"
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});
