<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/* authenication */
Route::get('/', 'LoginController@signin');
Route::get('admin/signin', 'LoginController@signin');
Route::post('admin/postSignin', 'LoginController@postSignin');
Route::post('admin/postSignin', 'LoginController@postSignin');
Route::get('logout', 'LoginController@logout');

/* user management */
Route::get('admin/dashboard', 'UserController@dashboard');
Route::get('admin/add-user', 'UserController@newUser');
Route::post('admin/saveUser', 'UserController@saveUser');
Route::get('admin/user-list', 'UserController@userList');
Route::get('admin/user/edit/{id}', 'UserController@editUser');
Route::post('admin/updateUser', 'UserController@updateUser');
Route::get('admin/deleteUser', 'UserController@deleteUser');
Route::post('admin/checkUser', 'UserController@checkUser');
Route::post('admin/checkUserPhone', 'UserController@checkUserPhone');

/* customer */
Route::get('customer/add', 'CustomerController@addCustomer');
Route::post('customer/save', 'CustomerController@saveCustomer');
Route::get('customer/all', 'CustomerController@viewAllCustomers');
Route::get('customer/edit/{id}', 'CustomerController@editCustomers');

/* product */
Route::get('admin/add-product', 'ProductController@addProduct');
Route::post('admin/saveProduct', 'ProductController@saveProduct');
Route::get('admin/all-products', 'ProductController@allProducts');
Route::get('admin/product/edit/{id}', 'ProductController@editProduct');
Route::post('admin/updateProduct', 'ProductController@updateProduct');
Route::get('admin/deletePhoto', 'ProductController@deletePhoto');
Route::get('admin/deleteProduct', 'ProductController@deleteProduct');

/* sales */
Route::get('admin/sales/pos', 'SaleController@pos');
Route::get('admin/sales/report/daily-sales', 'SaleController@dailySales');
Route::get('admin/sales/report/monthly-sales', 'SaleController@monthlySales');
Route::get('admin/sales/report/sales-report', 'SaleController@salesReport');
Route::post('admin/sales/add-user', 'SaleController@saveUser');
Route::post('admin/sales/searchUser', 'SaleController@searchUser');
Route::post('admin/sales/searchProduct', 'SaleController@searchProduct');
Route::get('admin/sales/sale-list', 'SaleController@sale');
Route::post('admin/sales/orders', 'SaleController@continueSale');
Route::post('payment', 'SaleController@payment');
Route::get('admin/sales/orders', 'SaleController@orders');
Route::post('admin/pos/invoice', 'SaleController@newSale');
Route::post('admin/sales/getProductPrice', 'SaleController@getProductPrice');
Route::get('admin/sales/pos/print', 'SaleController@posPrint');
Route::get('admin/pos/invoice', 'SaleController@invoice');
Route::post('admin/pos/repair-invoice', 'SaleController@repairService');
Route::get('admin/pos/repair-invoice', 'SaleController@repairInvoice');
Route::get('admin/pos/repair-tracking', 'SaleController@repairTracking');
Route::get('admin/sales/invoice', 'SaleController@saleInvoices');
Route::get('generate-invoice', 'SaleController@generateInvoice');
Route::get('repair-bill', 'SaleController@repairBill');
Route::get('admin/sale-billing', 'SaleController@saleInvoices');
Route::get('admin/service-billing', 'SaleController@serviceInvoice');
Route::get('admin/service/edit/{id}', 'SaleController@editService');
Route::post('updateService', 'SaleController@updateService');









