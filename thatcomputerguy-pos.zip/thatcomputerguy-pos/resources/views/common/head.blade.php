<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="{{ csrf_token() }}" />
    <title>{{$page_title}}</title>
    <link rel="icon" href="{{asset('public/images/fav-icon.png')}}" type="image/ico" />
    <link href="{{asset('public/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('public/css/custom.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('public/css/style.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('public/css/select2.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('public/css/bootstrap3-wysihtml5.min.css')}}" rel="stylesheet" type="text/css">
</head>