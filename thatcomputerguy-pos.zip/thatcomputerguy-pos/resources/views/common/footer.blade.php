<footer>
    <div class="pull-right">
        Copyright © 2018. All rights reserved.
    </div>
    <div class="clearfix"></div>
</footer>