@extends('products.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-9 col-xs-12">
                <div class="row">
                    <h1>Products List</h1>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12">
                <div class="row">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="#">Admin</a></li>
                        <li class="breadcrumb-item"><a href="#">Products</a></li>
                        <li class="breadcrumb-item active">Products List</li>
                    </ol>
                </div>
            </div>
            @if(session('err_msg'))
                <div id="success-msg" class="alert alert-success pull-left green-bg">
                    {{session('err_msg')}}
                </div>
            @endif
            <div id="delete-msg">
            </div>
            <a href="{{url('admin/add-product')}}">
                <button class="btn btn-success pull-right add-user">
                    <i class="fa fa-plus"></i> Add Product
                </button>
            </a>
            <div class="col-sm-12 col-xs-12">
                <div class="row">
                    <div class="panel panel-primary panel-primary-custom">
                        <div class="panel-heading">
                            <h3 class="panel-title">All Products</h3>
                        </div>
                        <div class="table-list-user">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">Sr No.</th>
                                    <th scope="col">Title <i class="caret"></i></th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Price <i class="caret"></i> </th>
                                    <th scope="col">Created Date<i class="caret"></i></th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    $local_path = './public/uploads/';
                                    $wp_filename = 'http://dev.itcorporates.com/thecomputerguywp/wp-content/uploads/';
                                    ?>
                                    @if(isset($products))
                                        @foreach($products as $prod)
                                            <?php
                                            $price = \App\ProductDetail::where('post_id', $prod['ID'])->where('meta_key', '_price')->first();
                                            $imgKey = \App\ProductDetail::where('post_id', $prod['ID'])->where('meta_key', '_thumbnail_id')->first();
                                            if(isset($imgKey)) {
                                                $imgVal =   \App\ProductDetail::where('post_id', $imgKey['meta_value'])->where('meta_key', '_wp_attached_file')->first();
                                                $filename = $local_path.$imgVal['meta_value'];
                                            }
                                            $timestamp = strtotime($prod['created_at']);
                                            $date = date('D d, M, Y', $timestamp);
                                            ?>
                                            <tr id="record-{{$prod['ID']}}">
                                                <td>{{$i}}</td>
                                                <td>{{$prod['post_title']}}</td>
                                                <td>{{strip_tags($prod['post_content'])}}</td>
                                                <td>{{$price['meta_value']}}</td>
                                                <td>{{$date}}</td>
                                                <td width="20%">
                                                    @if(isset($imgKey))
                                                        @if(file_exists($filename))
                                                            <img src="{{asset('public/uploads/'.$imgVal['meta_value'])}}" width="10%" height="10%"/>
                                                        @else
                                                            <img src="{{$wp_filename.$imgVal['meta_value']}}" width="10%" height="10%"/>
                                                        @endif
                                                    @endif
                                                </td>
                                                <td>
                                                    <a href="{{url('admin/product/edit/'.$prod['ID'])}}" data-toggle="tooltip" title="Edit Product">
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                    <a href="javascript:void(0)" onclick="deleteProd({{$prod['ID']}});" data-toggle="tooltip" title="Delete Product">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php $i++; ?>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="7">No Records.</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                    @if(isset($products))
                        <div class="paginatio-row">
                            {{ $products->links() }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@stop
