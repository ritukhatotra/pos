@extends('products.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-8 col-xs-12 col-sm-offset-2">
                <div class="col-sm-9 col-xs-12">
                    <div class="row">
                        <h1>Add Product</h1>
                    </div>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="panel panel-primary panel-primary-custom">
                            <div class="panel-heading">
                                @if(session('err_msg'))
                                    <div class="alert alert-danger pull-left">
                                        {{session('err_msg')}}
                                    </div>
                                @endif
                            </div>
                            <div class="panel-body">
                                <form id="product-form" method="post" action="{{url('admin/saveProduct')}}" enctype="multipart/form-data">
                                    <input type="hidden" name="_token" value="{{csrf_token()}}"/>
                                    <div class="col-sm-12 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Title <span class="mandatory-field-icon">*</span></label>
                                            <input type="text" name="title" placeholder="Enter Product Title" value="" class="form-control" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Price <span class="mandatory-field-icon">*</span></label>
                                            <input type="text" name="price" placeholder="Enter Price" value="" class="form-control" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Description <span class="mandatory-field-icon">*</span></label>
                                            <textarea name="desc" class="textarea" placeholder="Enter product description here"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 margin-bottom-10">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <label class="input-group-btn">
                                                    <span class="btn btn-primary file-btn">
                                                        Browse&hellip; <input type="file" style="display: none;" name="prod_img[]" accept=".png,.jpg,.jpeg,.gif" multiple/>
                                                    </span>
                                                </label>
                                                <input type="text" class="form-control" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 ">
                                        <div class="form-group">
                                            <input type="submit" value="Add Product" class="pull-right"/>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2 col-xs-12">
                <div class="row">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="#">Admin</a></li>
                        {{--<li class="breadcrumb-item"><a href="#">Products</a></li>--}}
                        <li class="breadcrumb-item active">Add Product</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
@stop

