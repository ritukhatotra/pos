@extends('sales.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-12 col-xs-12">
                <div class="row">
                    <div id="invoice-print" class="panel panel-primary panel-primary-custom">
                        <div class="panel-heading">
                            <button class="btn btn-primary pull-right" id="print-btn">
                                <i class="fa fa-print"></i> Print
                            </button>
                            <h3 class="panel-title">Invoice</h3>
                        </div>
                        <div id="invoice" class="panel-body">
                            <div class="col-sm-12 col-xs-12">
                                <p>INVOICE {{$invoice}}</p>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-sm-12 col-xs-12">
                                <h1>That Computer Guy</h1>
                                <h5>ADDRESS</h5>
                                <span>1000 Bishop St. North Cambridge ON, N3H 4V7</span>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-sm-12">
                                DATE: {{date('D d, M, Y', $date)}}
                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <h6>BILL TO</h6>
                                <p><strong>Name:</strong> {{ucwords($cust_name)}}</p>
                                <p><strong>Email:</strong> {{$cust_email}}</p>
                                <p><strong>Address:</strong>
                                    {{ substr($cust_address.'...', 0, 30)}}
                                </p>
                                <p><strong>Phone:</strong> {{$cust_phone}}</p>
                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <h6>FOR</h6>
                                <p>{{ucwords($prod_name)}}</p>
                            </div>
                            <div class="clearfix"></div>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Sr. No</th>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Reward Points</th>
                                    <th>Reward Points Check</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>{{ucwords($prod_name)}}</td>
                                    <td>${{$prod_price}}</td>
                                    <td>{{$quantity}}</td>
                                    <td>{{$reward}}</td>
                                    <td>{{strtoupper($reward_check)}}</td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="clearfix"></div>
                            <div class="col-sm-12 col-xs-12 col-sm-offset-8">
                                <p>SUBTOTAL: ${{$subtotal}}</p>
                                <p>TAX RATE: {{$tax * 100}}%</p>
                                <p>DISCOUNT: {{$discount}}&nbsp;&nbsp;&nbsp;<strong>(10% of reward points)</strong></p>
                                <p>TOTAL: ${{$total}}</p>
                            </div>
                            <div class="clearfix"></div>
                            <p>Make all checks payable to <strong>That Computer Guy</strong></p>
                            <p>If you have any questions concerning the invoice, use the following contact info:</p>
                            <p><i class="fa fa-envelope"></i> info@thatcomputerguy.org</p>
                            <p><i class="fa fa-phone"></i> 519.219.2525</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop