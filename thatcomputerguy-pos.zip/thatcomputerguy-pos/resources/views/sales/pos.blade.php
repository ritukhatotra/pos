@extends('sales.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-8 col-xs-12">
                <div class="row">
                    <div class="panel panel-primary panel-primary-custom">
                        <div class="panel-heading">
                            <h3 class="panel-title">Please fill in the information below</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="select">
                                    <input name="search-user" id="search-user" placeholder="Search user by phone number" value="" class="form-control" type="text" autocomplete="off">
                                    <a href="javascript:void(0);" id="search-go">Go</a>
                                </div>
                            </div>
                            <form  class="last-purchase-detail" id="pos" action="{{url('admin/sales/orders')}}" method="post">
                                <input type="hidden" name="_token" value="{{csrf_token()}}"/>
                                <div class="display-user hide-user form-group">
                                    <div class="form-group">
                                        <label for="posUser-name">Customer Name</label>
                                        <input type="text" name="posUser-name" id="posUser-name" value="" class="form-control" readonly/>
                                    </div>
                                    <div class="form-group">
                                        <label for="posUser-email">Customer Email</label>
                                        <input type="text" name="posUser-email" id="posUser-email" value="" class="form-control" readonly/>
                                    </div>
                                    <div class="form-group">
                                        <label for="posUser-phone">Contact Number</label>
                                        <input type="text" name="posUser-phone" id="posUser-phone" value="" class="form-control" readonly/>
                                    </div>
                                    <div class="form-group">
                                        <label for="posUser-address">Address</label>
                                        <textarea name="posUser-address" id="posUser-address" class="form-control" readonly></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <h4>Last Purchase Details:</h4>
                                    <table id="purchse-detail-table" class="table">
                                        <thead>
                                            <tr>
                                                <th>Products</th>
                                                <th>Total Amount</th>
                                                <th>Purchase Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td id="c1"></td>
                                                <td id="c2"></td>
                                                <td id="c3"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="form-group">
                                    <label for="reward">Reward Points</label>
                                    <input type="text" id="reward" name="reward" class="form-control"/>
                                </div>
                                <div class="form-group">
                                    <label for="reward">Redeem Value</label>
                                    $<input type="text" id="redeem" name="redeem" class="form-control"/>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Continue" class="btn btn-primary continue-pos" disabled="">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- popup section -->
    <!-- Pop up Plus icon-->
    <div class="modal fade pos-modal" id="newUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="panel panel-primary panel-primary-custom">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Please fill in the information below</h3>
                                </div>
                                <div class="panel-body">
                                    <form id="add-user-form-pos" method="post">
                                        <div class="form-group">
                                            <label>Full Name <span class="mandatory-field-icon">*</span></label>
                                            <input type="text" id="name" name="name" placeholder="Enter Full Name" value="" class="form-control" autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label>Email <span class="mandatory-field-icon">*</span></label>
                                            <input type="email" id="email" name="email" placeholder="Enter Email" value="" class="form-control" autocomplete="off">
                                            <span id="email-msg"></span>
                                        </div>
                                        <div class="form-group">
                                            <label>Contact Number <span class="mandatory-field-icon">*</span></label>
                                            <input type="tel" name="contact_number" id="contact_number" placeholder="Enter Contact Number" value="" class="form-control" autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label>Address <span class="mandatory-field-icon">*</span></label>
                                            <textarea name="address" placeholder="Enter Address..." class="form-control" autocomplete="off"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" value="Submit" class="full-width">
                                            <input type="submit" value="Close" data-dismiss="modal" class="full-width close-btn">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

