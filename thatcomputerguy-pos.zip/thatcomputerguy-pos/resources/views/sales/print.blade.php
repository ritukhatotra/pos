<!doctype html>
<html>
@include('common.head')
<body class="nav-md that-computer-guy">
<div class="login-page">
    <div class="middle-content">
        <div class="logo">
            <a href="#">
                <img src="{{asset('public/images/actual-logo.png')}}" alt="" />
            </a>
        </div>
        <div class="print login-form ">
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-6 col-xs-12">
                    <h4>Product Name:</h4>
                </div>
                <div class="col-sm-6 col-xs-12">
                    {{$product_title}}
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-6 col-xs-12">
                    <h4>Product Price:</h4>
                </div>
                <div class="col-sm-6 col-xs-12">
                    {{$price}}
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-6 col-xs-12">
                    <h4>Quantity:</h4>
                </div>
                <div class="col-sm-6 col-xs-12">
                    {{$quantity}}
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-6 col-xs-12">
                    <h4>Reward Point Benefit:</h4>
                </div>
                <div class="col-sm-6 col-xs-12">
                    {{$reward}}
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-6 col-xs-12">
                    <h4>Reward Point Check:</h4>
                </div>
                <div class="col-sm-6 col-xs-12">
                    {{strtoupper($rewardCheck)}}
                </div>
            </div>
        </div>
    </div>
</div>
<script src="{{asset('public/js/bootstrap.min.js')}}"></script>
<script>
window.print();
</script>
</body>
</html>

