@extends('sales.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-9 col-xs-12">
                <div class="row">
                    <h1>Sales Report</h1>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12">
                <div class="row">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="#">Admin</a></li>
                        <li class="breadcrumb-item"><a href="#">Sales</a></li>
                        <li class="breadcrumb-item active">Reports</li>
                    </ol>
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="row">
                    <div class="panel panel-primary panel-primary-custom sales-detail">
                        <div class="panel-heading">
                            <h3 class="panel-title">Please review the report below</h3>
                        </div>
                        <div class="panel-body">
                            <div class="col-sm-3 col-xs-12 padd-left-0 padd-r-r-0">
                                <div class="sales-clm blue-bg">
                                    <i class="fa fa-shopping-cart blue-dark-bg"></i>
                                    <div class="sales-value">
                                        <h4>Sales Value</h4>
                                        <h3 class="price">0.00</h3>
                                        <span class="progress-description">0 Sales | 0.00 Received | 0.00 Tax</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-12">
                                <div class="sales-clm orange-bg">
                                    <i class="fa fa-plus orange-dark"></i>
                                    <div class="sales-value">
                                        <h4>Purchase Value</h4>
                                        <h3 class="price">0.00</h3>
                                        <span class="progress-description">0 Sales | 0.00 Received | 0.00 Tax</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-12">
                                <div class="sales-clm red-bg">
                                    <i class="fa fa-circle-o red-dark"></i>
                                    <div class="sales-value">
                                        <h4>Expenses Value</h4>
                                        <h3 class="price">0.00</h3>
                                        <span class="progress-description">0 Sales | 0.00 Received | 0.00 Tax</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-12 padd-right-0">
                                <div class="sales-clm green-bg">
                                    <i class="fa fa-dollar green-dark"></i>
                                    <div class="sales-value">
                                        <h4>Profit and Loss</h4>
                                        <h3 class="price">0.00</h3>

                                        <span class="progress-description">0 Sales | 0.00 Received | 0.00 Tax</span>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-primary panel-primary-custom calender-table">
                                <div class="panel-heading">
                                    <div class="col-sm-2">
                                        <div class="row">
                                            <a href="#"><span class="lnr lnr-chevron-left pull-left arrow"></span></a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <h3 class="panel-title">June 2018</h3>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="row">
                                            <a href="#"><span class="lnr lnr-chevron-right pull-right arrow"></span></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-list-user">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th scope="col">Sunday</th>
                                            <th scope="col">Monday</th>
                                            <th scope="col">Tuesday</th>
                                            <th scope="col">Wednesday</th>
                                            <th scope="col">Thursday</th>
                                            <th scope="col">Friday</th>
                                            <th scope="col">Saturday</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>2</td>
                                            <td>3</td>
                                            <td>4</td>
                                            <td>5</td>
                                            <td>6</td>
                                            <td>7</td>
                                        </tr>
                                        <tr>
                                            <td>8</td>
                                            <td>9</td>
                                            <td>10</td>
                                            <td>11</td>
                                            <td>12</td>
                                            <td>13</td>
                                            <td>14</td>
                                        </tr>
                                        <tr>
                                            <td>15</td>
                                            <td>16</td>
                                            <td>17</td>
                                            <td>18</td>
                                            <td>19</td>
                                            <td>20</td>
                                            <td>21</td>
                                        </tr>
                                        <tr>
                                            <td>22</td>
                                            <td>23</td>
                                            <td>24</td>
                                            <td>25</td>
                                            <td>26</td>
                                            <td>27</td>
                                            <td>28</td>
                                        </tr>
                                        <tr>
                                            <td>29</td>
                                            <td>30</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

