@extends('sales.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-9 col-xs-12">
                <div class="row">
                    <h1>Sales List</h1>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12">
                <div class="row">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="#">Admin</a></li>
                        <li class="breadcrumb-item"><a href="#">Sales</a></li>
                        <li class="breadcrumb-item active">Sales List</li>
                    </ol>
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="row">
                    <div class="panel panel-primary panel-primary-custom">
                        <div class="panel-heading">
                            <h3 class="panel-title">Store</h3>
                        </div>
                        <div class="table-list-user">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Slip No.</th>
                                        <th scope="col">Customer Name</th>
                                        <th scope="col">Customer Email</th>
                                        <th scope="col">Customer Mobile</th>
                                        <th scope="col">Product</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Image</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    $local_path = './public/uploads/';
                                    $wp_filename = 'http://dev.itcorporates.com/thecomputerguywp/wp-content/uploads/';
                                    ?>
                                    @if(isset($payments))
                                        @foreach($payments as $payment)
                                            <?php
                                            $price = \App\ProductDetail::where('post_id', $payment['product_id'])->where('meta_key', '_price')->first();
                                            $imgKey = \App\ProductDetail::where('post_id', $payment['product_id'])->where('meta_key', '_thumbnail_id')->first();
                                            if(isset($imgKey)) {
                                                $imgVal =   \App\ProductDetail::where('post_id', $imgKey['meta_value'])->where('meta_key', '_wp_attached_file')->first();
                                                $filename = $local_path.$imgVal['meta_value'];
                                            }
                                            $user = \App\User::find($payment['user_id']);
                                            $userMeta = \App\UserMeta::where('user_id', $payment['user_id'])->first();
                                            $product = \App\Product::find($payment['product_id']);
                                            $timestamp = strtotime($payment['created_at']);
                                            $date = date('D d, M, Y', $timestamp);
                                            $subtotal = $price['meta_value'] * $payment['quantity'];
                                            ?>
                                            <tr>
                                                <td>{{$payment['slip_number']}}</td>
                                                <td>{{ucwords($userMeta['name'])}}</td>
                                                <td>{{$user['user_email']}}</td>
                                                <td>{{$userMeta['contact_number']}}</td>
                                                <td>{{$product['post_title']}}</td>
                                                <td>${{$price['meta_value']}}</td>
                                                <td>{{$payment['quantity']}}</td>
                                                <td>${{$subtotal}}</td>
                                                <td>{{$date}}</td>
                                                <td width="12%">
                                                    @if(isset($imgKey))
                                                        @if(file_exists($filename))
                                                            <img src="{{asset('public/uploads/'.$imgVal['meta_value'])}}" width="10%" height="10%"/>
                                                        @else
                                                            <img src="{{$wp_filename.$imgVal['meta_value']}}" width="10%" height="10%"/>
                                                        @endif
                                                    @endif
                                                </td>
                                            </tr>
                                            <?php $i++; ?>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="7">No Records.</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                    @if(isset($payments))
                        <div class="paginatio-row">
                            {{ $payments->links() }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@stop

