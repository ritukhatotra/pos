@extends('sales.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-5 col-xs-12">
                <div class="row">
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#new-service">New Sale</a></li>
                        <li><a data-toggle="tab" href="#repair">Repair Service</a></li>
                    </ul>
                    <div class="clearfix"></div>
                    <div class="tab-content">
                        <div id="new-service" class="tab-pane fade in active panel panel-primary panel-primary-custom">
                            <div class="panel-heading">
                                <h3 class="panel-title">New Sale</h3>
                            </div>
                            <div class="panel-body">
                                <form id="new-sale" method="post" action="{{url('admin/pos/invoice')}}">
                                    <input type="hidden" name="_token" value="{{csrf_token()}}"/>
                                    <input type="hidden" name="user_id" value="{{$user_id}}"/>
                                    <div class="form-group">
                                        <div class="select-box">
                                            @if(isset($products))
                                                <select id='pos-product' name="product" class="form-control">
                                                    <option value=''>Select Product</option>
                                                    @foreach($products as $product)
                                                        <option value='{{$product['ID']}}'>{{ucfirst($product['post_title'])}}</option>
                                                    @endforeach
                                                </select>
                                                <span class="lnr lnr-chevron-down"></span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="price">Price</label>
                                        <input type="text" name="prod_price" id="prod_price" class="form-control"  readonly/>
                                    </div>
                                    <div class="form-group">
                                        <label for="quantity">Quantity</label>
                                        <input type="text" name="quantity" id="quantity" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label for="quantity">Reward Point Benefit</label>
                                        <input type="text" name="reward_benefit" class="form-control" value="{{$reward}}" readonly />
                                        <input type="radio" name="reward_check" value="applied"> Applied<br>
                                        <input type="radio" name="reward_check" value="na"> NA<br>
                                    </div>
                                    <div class="form-group">
                                        <label for="redeem">Redeem</label>
                                        <input type="text" id="redeem" name="redeem" class="form-control" value="{{$redeem}}" readonly />
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" name="submit" class="btn btn-primary" value="Sell" />
                                        <input type="button" name="preview" class="btn btn-primary" value="Preview" id="previewDetail"/>
                                        <a onclick="printPos();">
                                            <input type="button" name="print" class="btn btn-primary" value="Print" id="posPrint"/>
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- repair -->
                        <?php
                        /* random slip number */
                        $numbers = '0123456789';
                        $numbersLength = strlen($numbers);
                        $randomNumber = '';
                        $length = 3;
                        for ($i = 0; $i < $length; $i++) {
                            $randomNumber .= $numbers[rand(0, $numbersLength - 1)];
                        }

                        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                        $charsLength = strlen($chars);
                        $charString = '';
                        $leng = 1;
                        for ($i = 0; $i < $leng; $i++) {
                            $charString .= $chars[rand(0, $charsLength - 1)];
                        }
                        $slip = '#'.$randomNumber.$charString;
                        /* end slip number */
                        ?>
                        <div id="repair" class="tab-pane fade panel panel-primary panel-primary-custom">
                            <div class="panel-heading">
                                <h3 class="panel-title">Repair</h3>
                            </div>
                            <div class="panel-body">
                                <form id="repair-form" method="post" action="{{url('admin/pos/repair-invoice')}}">
                                    <input type="hidden" name="_token" value="{{csrf_token()}}"/>
                                    <input type="hidden" name="user_id" value="{{$user_id}}"/>
                                    <div class="form-group">
                                        <label for="slip">Slip Number:</label>
                                        <input type="text" name="slip" id="slip" class="form-control" value="{{$slip}}" readonly/>
                                    </div>
                                    <div class="form-group">
                                        <div class="select-box">
                                            @if(isset($products))
                                                <select id='repair-service' name="service" class="form-control">
                                                    <option value=''>Select Service</option>
                                                    @foreach($products as $product)
                                                        <option value='{{$product['ID']}}'>{{ucfirst($product['post_title'])}}</option>
                                                    @endforeach
                                                </select>
                                                <span class="lnr lnr-chevron-down"></span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="sts">Status</label>
                                        <div class="select-box">
                                            <select id="sts" name="status" class="form-control">
                                                <option value=''>Select Status</option>
                                                <option value='HOLD'>Hold</option>
                                                <option value='PENDING'>Pending</option>
                                                <option value='CANCELLED'>Cancelled</option>
                                                <option value='COMPLETED'>Completed</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="repair_part">Fault Part of Service:</label>
                                        <textarea id="repair_part" name="repair_part" class="form-control"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="service_price">Price</label>
                                        <input type="text" name="service_price" id="service_price" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" name="submit" class="btn btn-primary" value="Repair" />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Popup -->
    <div class="modal fade pos-modal " id="previewModal" tabindex="-1" role="dialog" aria-labelledby="previewModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="panel panel-primary panel-primary-custom">
                                <div class="panel-body table-list-user">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Reward Point Benefit</th>
                                                <th>Reward Point Benefit Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td id="col1"></td>
                                                <td id="col2"></td>
                                                <td id="col3"></td>
                                                <td id="col4"></td>
                                                <td id="col5"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                <div class="clearfix"></div>
								<div class="form-group">
									<input type="submit" value="Close" data-dismiss="modal" class="close-btn dashboard-btn pull-right">
								</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop



