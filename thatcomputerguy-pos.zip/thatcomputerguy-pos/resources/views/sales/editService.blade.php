@extends('sales.main')
@section('content')
    <div class="right_col" role="main">
        <div class="right-content-part">
            <div class="col-sm-8 col-xs-12 col-sm-offset-2">
                <div class="col-sm-9 col-xs-12">
                    <div class="row">
                        <h1>Edit Repair Service</h1>
                    </div>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="panel panel-primary panel-primary-custom">
                            <div class="panel-body">
                                <form id="edit-service-form" method="post" action="{{url('updateService')}}" enctype="multipart/form-data">
                                    @if(session('msg'))
                                        <div class="alert alert-success green-bg">
                                            {{session('msg')}}
                                        </div>
                                    @endif
                                    {{csrf_field()}}
                                    <input type="hidden" name="id" value="{{$payment->id}}"/>
                                    <div class="col-sm-6 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Slip Number</label>
                                            <input type="text" value="{{$payment->slip_number}}" readonly class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Customer Name</label>
                                            <input type="text" value="{{ucwords($userMeta['name'])}}" readonly class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Customer Email</label>
                                            <input type="text" value="{{ucfirst($user->user_email)}}" readonly class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Customer Mobile</label>
                                            <input type="text" value="{{$userMeta['contact_number']}}" readonly class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Service</label>
                                            <input type="text" value="{{ucfirst($product->post_title)}}" readonly class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Fault</label>
                                            <input type="text" name="fault" value="{{ucfirst($payment->repair_part)}}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label>Price</label>
                                            <input type="text" name="price" value="{{$payment->service_price}}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-xs-12 margin-bottom-10">
                                        <div class="form-group">
                                            <label for="sts">Status</label>
                                            <div class="select-box">
                                                <select name="status" class="form-control">
                                                    <option value='{{$payment->status}}'>{{$payment->status}}</option>
                                                    <option value='HOLD'>Hold</option>
                                                    <option value='PENDING'>Pending</option>
                                                    <option value='CANCELLED'>Cancelled</option>
                                                    <option value='COMPLETED'>Completed</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 ">
                                        <div class="form-group">
                                            <input type="submit" value="Update" class="pull-right"/>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2 col-xs-12">
                <div class="row">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="#">Admin</a></li>
                        <li class="breadcrumb-item active">Edit Product</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
@stop

