<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="row" id="">
            <div class="spinner" id="grid-loader" style="display:none">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
            </div>
            <div class="col-md-12">
                <form id="employee_form" class="form-horizontal" method="post" action="<?php echo e(url('update-employee')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="panel panel-piluku">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <i class="ion-edit"></i>
                                Edit Employee Information<small> (Fields in red are required)</small>
                            </h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="first_name" class="col-sm-3 col-md-3 col-lg-2 control-label red">First Name:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="first_name" value="<?php echo e($user->first_name); ?>" class="form-control" id="first_name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="last_name" class=" col-sm-3 col-md-3 col-lg-2 control-label ">Last Name:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="last_name" value="<?php echo e($user->last_name); ?>" class="form-control" id="last_name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="email" class="col-sm-3 col-md-3 col-lg-2 control-label red">E-Mail:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control" id="email">
                                            <span id="email-msg"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone_number" class="col-sm-3 col-md-3 col-lg-2 control-label ">Phone Number:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="form-control" id="phone_number">
                                            <span id="phone-msg"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="image_id" class="col-sm-3 col-md-3 col-lg-2 control-label ">Select Image:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <ul class="list-unstyled avatar-list">
                                                <li>
                                                    <input type="file" name="profile_photo" id="profile" class="filestyle">
                                                </li>
                                                <li>
                                                    <div id="avatar">
                                                        <img style="width: 20%; margin-top:10px;" src="<?php echo e(asset('public/images/'.$user->profile_photo)); ?>" class="img-polaroid" id="avatar-photo" alt="">
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="address_1" class="col-sm-3 col-md-3 col-lg-2 control-label ">Address 1:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="address1" value="<?php echo e($user->address1); ?>" class="form-control" id="address_1">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="address_2" class="col-sm-3 col-md-3 col-lg-2 control-label ">Address 2:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="address2" value="<?php echo e($user->address2); ?>" class="form-control" id="address_2">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="country" class="col-sm-3 col-md-3 col-lg-2 control-label ">Country:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="countries_id" class="form-control" id="country">
                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country['id']); ?>"><?php echo e($country['name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="state" class="col-sm-3 col-md-3 col-lg-2 control-label ">State/Province:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="states_id" class="form-control" id="state">
                                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="city" class="col-sm-3 col-md-3 col-lg-2 control-label ">City:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="city" value="<?php echo e($user->city); ?>" class="form-control " id="city">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="zip" class="col-sm-3 col-md-3 col-lg-2 control-label ">Zip:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="zip" value="" class="form-control " id="zip">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="comments" class="col-sm-3 col-md-3 col-lg-2 control-label ">Comments:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <textarea name="comment" cols="17" rows="5" id="comments" class="form-control text-area"></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="commission_percent" class="col-sm-3 col-md-3 col-lg-2 control-label">Commission Default Rate:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group">
                                                <input type="text" name="commission_percent" value="" id="commission_percent" class="form-control">
                                                <span class="input-group-addon">%</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="commission_percent_type" class="col-sm-3 col-md-3 col-lg-2 control-label">Commission Percent calculation method: </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="commission_percent_type" class="form-control" id="commission_percent_type">
                                                <option value="selling_price">Selling Price</option>
                                                <option value="profit">Profit</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="hourly_pay_rate" class="col-sm-3 col-md-3 col-lg-2 control-label">Hourly pay rate</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group">
                                                <div class="input-group-addon">$</div>
                                                <input type="text" name="hourly_pay_rate" value="" id="hourly_pay_rate" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group offset1">
                                        <label for="hire_date" class="col-sm-3 col-md-3 col-lg-2 control-label text-info wide">Hire date:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group date">
                                                <span class="input-group-addon bg">
                                                    <i class="ion ion-ios-calendar-outline"></i>
                                                </span>
                                                <input type="text" name="doj" value="" id="hire_date" class="form-control datepicker">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group offset1">
                                        <label for="birthday" class="col-sm-3 col-md-3 col-lg-2 control-label text-info wide">Birthday:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group date">
                                                <span class="input-group-addon bg">
                                                    <i class="ion ion-ios-calendar-outline"></i>
                                                </span>
                                                <input type="text" name="dob" value="" id="birthday" class="form-control datepicker">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="user_roles_id" value="2" id="employee_number" class="form-control">
                                    <div class="form-group">
                                        <label for="language" class="col-sm-3 col-md-3 col-lg-2 col-sm-3 col-md-3 col-lg-2 control-label  required">Language:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="language" class="form-control" id="language">
                                                <option value="english" selected="selected">English</option>
                                                <option value="indonesia">Indonesia</option>
                                                <option value="spanish">Español</option>
                                                <option value="french">Fançais</option>
                                                <option value="italian">Italiano</option>
                                                <option value="german">Deutsch</option>
                                                <option value="dutch">Nederlands</option>
                                                <option value="portugues">Portugues</option>
                                                <option value="arabic">العَرَبِيةُ&lrm;&lrm;</option>
                                                <option value="khmer">Khmer</option>
                                                <option value="vietnamese">Vietnamese</option>
                                                <option value="chinese">中文</option>
                                                <option value="chinese_traditional">繁體中文</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-piluku">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><i class="ion-folder"></i>Files</h3>
                                </div>
                                <h4 style="padding: 20px;">Add Files</h4>
                                <div class="form-group" style="padding-left: 10px;">
                                    <label for="files_1" class="col-sm-3 col-md-3 col-lg-2 control-label ">File 1:</label>
                                    <div class="col-sm-9 col-md-9 col-lg-10">
                                        <div class="file-upload">
                                            <input type="file" name="name[]" id="files_1">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group" style="padding-left: 10px;">
                                    <label for="files_2" class="col-sm-3 col-md-3 col-lg-2 control-label ">File 2:</label>
                                    <div class="col-sm-9 col-md-9 col-lg-10">
                                        <div class="file-upload">
                                            <input type="file" name="name[]" id="files_2">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group" style="padding-left: 10px;">
                                    <label for="files_3" class="col-sm-3 col-md-3 col-lg-2 control-label ">File 3:</label>
                                    <div class="col-sm-9 col-md-9 col-lg-10">
                                        <div class="file-upload">
                                            <input type="file" name="name[]" id="files_3">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group" style="padding-left: 10px;">
                                    <label for="files_4" class="col-sm-3 col-md-3 col-lg-2 control-label ">File 4:</label>
                                    <div class="col-sm-9 col-md-9 col-lg-10">
                                        <div class="file-upload">
                                            <input type="file" name="name[]" id="files_4">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group" style="padding-left: 10px;">
                                    <label for="files_5" class="col-sm-3 col-md-3 col-lg-2 control-label ">File 5:</label>
                                    <div class="col-sm-9 col-md-9 col-lg-10">
                                        <div class="file-upload">
                                            <input type="file" name="name[]" id="files_5">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-piluku">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="ion-locked"></i>
                                        Employee Login Info
                                    </h3>
                                </div>

                                <div class="panel-body">
                                    <div class="form-group">
                                        <label for="username" class="col-sm-3 col-md-3 col-lg-2 control-label required">Username:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="username" value="" id="username" class="form-control">
                                            <span id="uname"></span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="password" class="col-sm-3 col-md-3 col-lg-2 control-label">Password:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="password" name="password" value="" id="password" class="form-control" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="repeat_password" class="col-sm-3 col-md-3 col-lg-2 control-label">Password Again:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="password" name="repeat_password" value="" id="repeat_password" class="form-control" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="force_password_change" class="col-sm-3 col-md-3 col-lg-2 control-label">Force password change upon login:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="checkbox" name="force_password_changed" value="1" id="force_password_change">
                                            <label for="force_password_change"><span></span></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="always_require_password" class="col-sm-3 col-md-3 col-lg-2 control-label">
                                            Always require password when switching user:
                                        </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="checkbox" name="always_required_password" value="1" id="always_require_password">
                                            <label for="always_require_password"><span></span></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inactive" class="col-sm-3 col-md-3 col-lg-2 control-label">Inactive:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="checkbox" name="status" value="inactive" id="inactive">
                                            <label for="inactive"><span></span></label>
                                        </div>
                                    </div>
                                    <div id="inactive_info" class="hidden">
                                        <div class="form-group">
                                            <label for="reason_inactive" class="col-sm-3 col-md-3 col-lg-2 control-label ">Reason inactive:</label>
                                            <div class="col-sm-9 col-md-9 col-lg-10">
                                                <textarea name="reason_for_status_inactive" cols="17" rows="5" id="reason_inactive" class="form-control text-area"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group offset1">
                                            <label for="termination_date" class="col-sm-3 col-md-3 col-lg-2 control-label text-info wide">Termination date:</label>
                                            <div class="col-sm-9 col-md-9 col-lg-10">
                                                <div class="input-group date">
                                                    <span class="input-group-addon bg">
                                                        <i class="ion ion-ios-calendar-outline"></i>
                                                    </span>
                                                    <input type="text" name="inactive_date" value="" id="termination_date" class="form-control datepicker">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions">
                                <input type="submit" name="submit" value="Save" id="submit" class=" submit_button floating-button btn btn-lg btn-primary">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>@extends('admin.main')
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="row" id="">
            <div class="spinner" id="grid-loader" style="display:none">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
            </div>
            <div class="col-md-12">
                <form id="employee_form" class="form-horizontal" method="post" action="<?php echo e(url('save-employee')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="panel panel-piluku">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <i class="ion-edit"></i>
                                Employee Information<small> (Fields in red are required)</small>
                            </h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="first_name" class="col-sm-3 col-md-3 col-lg-2 control-label red">First Name:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="first_name" value="" class="form-control" id="first_name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="last_name" class=" col-sm-3 col-md-3 col-lg-2 control-label ">Last Name:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="last_name" value="" class="form-control" id="last_name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="email" class="col-sm-3 col-md-3 col-lg-2 control-label red">E-Mail:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="email" value="" class="form-control" id="email">
                                            <span id="email-msg"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone_number" class="col-sm-3 col-md-3 col-lg-2 control-label ">Phone Number:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="phone" value="" class="form-control" id="phone_number">
                                            <span id="phone-msg"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="image_id" class="col-sm-3 col-md-3 col-lg-2 control-label ">Select Image:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <ul class="list-unstyled avatar-list">
                                                <li>
                                                    <input type="file" name="profile_photo" id="profile" class="filestyle">
                                                </li>
                                                <li>
                                                    <div id="avatar">
                                                        <img style="width: 20%; margin-top:10px;" src="<?php echo e(asset('public/images/avatar-default.jpg')); ?>" class="img-polaroid" id="avatar-photo" alt="">
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="address_1" class="col-sm-3 col-md-3 col-lg-2 control-label ">Address 1:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="address1" value="" class="form-control" id="address_1">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="address_2" class="col-sm-3 col-md-3 col-lg-2 control-label ">Address 2:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="address2" value="" class="form-control" id="address_2">
                                        </div>
                                    </div>
                                    <?php
                                    $country = '';
                                    $state = '';
                                    if($customer->countries_id != '') {
                                        $country = \App\Country::find($customer->countries_id);
                                    }
                                    if($customer->states_id != '') {
                                        $state = \App\State::find($customer->states_id);
                                    }
                                    ?>
                                    <div class="form-group">
                                        <label for="country" class="col-sm-3 col-md-3 col-lg-2 control-label ">Country:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="countries_id" class="form-control" id="country">
                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country['id']); ?>"><?php echo e($country['name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="state" class="col-sm-3 col-md-3 col-lg-2 control-label ">State/Province:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="states_id" class="form-control" id="state">
                                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="city" class="col-sm-3 col-md-3 col-lg-2 control-label ">City:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="city" value="" class="form-control " id="city">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="zip" class="col-sm-3 col-md-3 col-lg-2 control-label ">Zip:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="zip" value="" class="form-control " id="zip">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="comments" class="col-sm-3 col-md-3 col-lg-2 control-label ">Comments:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <textarea name="comment" cols="17" rows="5" id="comments" class="form-control text-area"></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="commission_percent" class="col-sm-3 col-md-3 col-lg-2 control-label">Commission Default Rate:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group">
                                                <input type="text" name="commission_percent" value="" id="commission_percent" class="form-control">
                                                <span class="input-group-addon">%</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="commission_percent_type" class="col-sm-3 col-md-3 col-lg-2 control-label">Commission Percent calculation method: </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="commission_percent_type" class="form-control" id="commission_percent_type">
                                                <option value="selling_price">Selling Price</option>
                                                <option value="profit">Profit</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="hourly_pay_rate" class="col-sm-3 col-md-3 col-lg-2 control-label">Hourly pay rate</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group">
                                                <div class="input-group-addon">$</div>
                                                <input type="text" name="hourly_pay_rate" value="" id="hourly_pay_rate" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group offset1">
                                        <label for="hire_date" class="col-sm-3 col-md-3 col-lg-2 control-label text-info wide">Hire date:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group date">
                                                <span class="input-group-addon bg">
                                                    <i class="ion ion-ios-calendar-outline"></i>
                                                </span>
                                                <input type="text" name="doj" value="" id="hire_date" class="form-control datepicker">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group offset1">
                                        <label for="birthday" class="col-sm-3 col-md-3 col-lg-2 control-label text-info wide">Birthday:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <div class="input-group date">
                                                <span class="input-group-addon bg">
                                                    <i class="ion ion-ios-calendar-outline"></i>
                                                </span>
                                                <input type="text" name="dob" value="" id="birthday" class="form-control datepicker">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="user_roles_id" value="2" id="employee_number" class="form-control">
                                    <div class="form-group">
                                        <label for="language" class="col-sm-3 col-md-3 col-lg-2 col-sm-3 col-md-3 col-lg-2 control-label  required">Language:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <select name="language" class="form-control" id="language">
                                                <option value="english" selected="selected">English</option>
                                                <option value="indonesia">Indonesia</option>
                                                <option value="spanish">Español</option>
                                                <option value="french">Fançais</option>
                                                <option value="italian">Italiano</option>
                                                <option value="german">Deutsch</option>
                                                <option value="dutch">Nederlands</option>
                                                <option value="portugues">Portugues</option>
                                                <option value="arabic">العَرَبِيةُ&lrm;&lrm;</option>
                                                <option value="khmer">Khmer</option>
                                                <option value="vietnamese">Vietnamese</option>
                                                <option value="chinese">中文</option>
                                                <option value="chinese_traditional">繁體中文</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-piluku">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="ion-locked"></i>
                                        Employee Login Info
                                    </h3>
                                </div>

                                <div class="panel-body">
                                    <div class="form-group">
                                        <label for="username" class="col-sm-3 col-md-3 col-lg-2 control-label required">Username:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="text" name="username" value="" id="username" class="form-control">
                                            <span id="uname"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="always_require_password" class="col-sm-3 col-md-3 col-lg-2 control-label">
                                            Always require password when switching user:
                                        </label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="checkbox" name="always_required_password" value="1" id="always_require_password">
                                            <label for="always_require_password"><span></span></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inactive" class="col-sm-3 col-md-3 col-lg-2 control-label">Inactive:</label>
                                        <div class="col-sm-9 col-md-9 col-lg-10">
                                            <input type="checkbox" name="status" value="inactive" id="inactive">
                                            <label for="inactive"><span></span></label>
                                        </div>
                                    </div>
                                    <div id="inactive_info" class="hidden">
                                        <div class="form-group">
                                            <label for="reason_inactive" class="col-sm-3 col-md-3 col-lg-2 control-label ">Reason inactive:</label>
                                            <div class="col-sm-9 col-md-9 col-lg-10">
                                                <textarea name="reason_for_status_inactive" cols="17" rows="5" id="reason_inactive" class="form-control text-area"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group offset1">
                                            <label for="termination_date" class="col-sm-3 col-md-3 col-lg-2 control-label text-info wide">Termination date:</label>
                                            <div class="col-sm-9 col-md-9 col-lg-10">
                                                <div class="input-group date">
                                                    <span class="input-group-addon bg">
                                                        <i class="ion ion-ios-calendar-outline"></i>
                                                    </span>
                                                    <input type="text" name="inactive_date" value="" id="termination_date" class="form-control datepicker">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions">
                                <input type="submit" name="submit" value="Update" id="submit" class=" submit_button floating-button btn btn-lg btn-primary">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>