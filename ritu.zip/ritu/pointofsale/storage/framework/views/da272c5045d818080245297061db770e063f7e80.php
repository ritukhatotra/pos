<?php if($current_url == env('APP_URL').'admin/new-customer'): ?>
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
        <a href="<?php echo e(url('admin/customers')); ?>">Customers</a>
        <a href="<?php echo e(url('admin/new-custmer')); ?>">New Customer</a>
    </div>
<?php elseif($current_url == env('APP_URL').'admin/customers'): ?>
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
        <a href="<?php echo e(url('admin/customers')); ?>">Customers</a>
    </div>
<?php elseif($current_url == env('APP_URL').'admin/customer/edit/'.Request::segment(4)): ?>
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
        <a href="<?php echo e(url('admin/customers')); ?>">Customers</a>
        <a href="<?php echo e(url('admin/customer/edit').'/'.Request::segment(4)); ?>">Edit Customer</a>
    </div>
<?php elseif($current_url == env('APP_URL').'admin/new-employee'): ?>
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
        <a href="<?php echo e(url('admin/employees')); ?>">Employees</a>
        <a href="<?php echo e(url('admin/new-employee')); ?>">New Employee</a>
    </div>
<?php elseif($current_url == env('APP_URL').'admin/employees'): ?>
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
        <a href="<?php echo e(url('admin/employees')); ?>">Employees</a>
    </div>
<?php else: ?>
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
    </div>
<?php endif; ?>
