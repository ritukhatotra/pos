<!doctype html>
<html>
<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
    <div class="wrapper sales-bar mini-bar">
        <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content" id="content">
            <?php echo $__env->make('common.top_navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            
        </div>
    </div>
<script src="<?php echo e(asset('public/js/all.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/admin/common.js')); ?>"></script>
<?php if($current_url == env('APP_URL').'admin/new-employee' || $current_url == env('APP_URL').'admin/employees' || $current_url == env('APP_URL').'admin/employee/edit/'.Request::segment(4)): ?>
    <script src="<?php echo e(asset('public/js/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/admin/employee.js')); ?>"></script>
<?php endif; ?>
<?php if($current_url == env('APP_URL').'admin/new-customer' || $current_url == env('APP_URL').'admin/customers' || $current_url == env('APP_URL').'admin/customer/edit/'.Request::segment(4)): ?>
    <script src="<?php echo e(asset('public/js/admin/customer.js')); ?>"></script>
<?php endif; ?>
<?php if($current_url == env('APP_URL').'admin/items' || $current_url == env('APP_URL').'admin/new-item'): ?>
    <script src="<?php echo e(asset('public/js/admin/item.js')); ?>"></script>
<?php endif; ?>
</body>
</html>

