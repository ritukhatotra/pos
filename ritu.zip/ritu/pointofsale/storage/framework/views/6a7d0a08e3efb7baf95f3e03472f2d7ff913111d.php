<!doctype html>
<html>
<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="nav-md that-computer-guy">
<div class="login-page">
    <div class="middle-content">
        <div class="login-form">
            <?php if(session('err_msg')): ?>
                <div class="alert alert-success pull-left green-bg">
                    <?php echo session('err_msg'); ?>
                </div>
            <?php endif; ?>
            <h4>Please login to your account.</h4>
            <form id="login-form" action="<?php echo e(url('admin/signin')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <input type="text" name="email" placeholder="Email" value="" class="form-control" autocomplete="off">
                </div>

                <div class="form-group">
                    <input type="password" name="password" placeholder="Password" value="" class="form-control" autocomplete="off">
                </div>
                <div class="form-group">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" value="">
                            <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                            Remember me
                        </label>
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" value="Submit" class="full-width">
                </div>
            </form>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('public/js/all.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/admin/admin.js')); ?>"></script>
</body>
</html>

