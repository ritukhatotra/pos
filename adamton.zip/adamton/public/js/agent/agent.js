 let BASE_URL = "http://localhost/adamton/";
//let BASE_URL = "http://dev.itcorporates.com/tokencms/tokencmslogin/";

/* get state by country id */
$("#country-select").on('change', function(){
    let cid = $("#country-select option:selected").val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'get-state',
        data : {cid : cid},
        success: function(res) {
            $('.state-select').removeClass('select-hide');
            $('#state-select').html(res);
        }
    });
});

/* get state by country id */
$("#state-select").on('change', function(){
    let sid = $("#state-select option:selected").val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'get-city',
        data : {sid : sid},
        success: function(res) {
            $('.city-select').removeClass('select-hide');
            $('#city-select').html(res);
        }
    });
});

/* form validation on new agent */
$(function() {
    $("#agent-reg-form").validate({
        rules: {
            country: "required",
            state: "required",
            name: "required",
            email: {
                required: true,
                email: true
            },
            uname: {
                required: true
            },
            password: {
                required: true
            },
            address: {
                required:true
            },
            mobile: {
                required: true,
                number: true
            }
        },
        submitHandler: function(form) {
           form.submit();
        }
    });
});

/* check duplicate user */
$("#email").blur(function(){
    let email = $(this).val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'check-email',
        data : {email : email},
        success: function(res) {
            if(res === 'exist') {
                $('#email-msg').html('Email already exist.');
            } else {
                $('#email-msg').html('');
            }
        }
    });
});

$("#uname").blur(function(){
    let uname = $(this).val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'check-username',
        data : {uname : uname},
        success: function(res) {
            if(res === 'exist') {
                $('#username-msg').html('Username already exist.');
            } else {
                $('#username-msg').html('');
            }
        }
    });
});

$("#mobile").blur(function(){
    let mobile = $(this).val();
    $.ajax({
        type : 'POST',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
        url  : BASE_URL+'check-phone',
        data : {mobile : mobile},
        success: function(res) {
            if(res === 'exist') {
                $('#mobile-msg').html('Phone number already exist.');
            } else {
                $('#mobile-msg').html('');
            }
        }
    });
});

/* form validation on login */
$(function() {
    $("#login-form").validate({
        rules: {
            email: {
                required: true,
                email: true
            },
            password: {
                required: true
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});