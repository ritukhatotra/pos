<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="{{ csrf_token() }}" />
    <title>{{$page_title}}</title>
    <link href="{{asset('public/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('public/css/style.css')}}" rel="stylesheet" type="text/css">
    <link rel="preconnect" href="//fonts.googleapis.com">
    <!--[if lt IE 9]>
    <script src="{{asset('public/js/html5shiv.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('public/js/respond.min.js')}}" type="text/javascript"></script>
    <![endif]-->
</head>