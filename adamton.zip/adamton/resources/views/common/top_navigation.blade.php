<?php
$base_url = "http://dev.itcorporates.com/tokencms/";
?>
<header class="header">
    <div class="top-bar site-layout">
        <div class="container">
            <div class="row">
                <div class="col-sm-7">
                   <div class="logo-signup">
						<img src="{{asset('public/images/logo.svg')}}">
				   </div>
                </div>
                <div class="col-sm-5 col-12">
                    <div class="float-right log-out-icon">
                        @if(Auth::user() != '')
                            <?php
                            $extractName = explode("@",Auth::user()->email);
                            $username = $extractName[0];
                            ?>
                            <span>Welcome {{ucfirst($username)}}</span>
                            <a href="{{url('logout')}}"><i class="fa fa-power-off"></i></a>
                        @endif
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</header>
