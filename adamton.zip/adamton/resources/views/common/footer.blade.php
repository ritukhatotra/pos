<footer class="footer site-layout">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="footer-logo">
                    <a href="#"><img src="{{asset('public/images/footer-logo.png')}}" alt=""></a>
                </div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                    the </p>
                <a href="#">Read More <span class="lnr lnr-chevron-right"></span></a>
            </div>
            <div class="col-md-4 col-sm-6">
                <h2>Contact us</h2>
                <div class="address-row">
                    <div class="row">
                        <div class="col-sm-1 col-1">
                            <div class="row">
                                <i class="fa fa-map-marker"></i>
                            </div>
                        </div>
                        <div class="col-sm-10 col-10">
                            <span>Lorum ipsum, Street No., Pin code, Country Name</span>
                        </div>
                    </div>
                </div>
                <div class="address-row">
                    <div class="row">
                        <div class="col-sm-1 col-1">
                            <div class="row">
                                <i class="fa fa-phone"></i>
                            </div>
                        </div>
                        <div class="col-sm-10 col-10">
                            <span>(+123) 123 - 456</span>
                        </div>
                    </div>
                </div>
                <div class="address-row">
                    <div class="row">
                        <div class="col-sm-1 col-1">
                            <div class="row">
                                <i class="fa fa-envelope"></i>
                            </div>
                        </div>

                        <div class="col-sm-10 col-10">
                            <span>info@gmail.com</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <h2>Newsletter</h2>
                <input type="email" name="Email" value="" placeholder="Email Address" class="form-control">
                <input type="submit" value="Submit" class="submit">
            </div>
            <div class="col-md-2 col-sm-6">
                <h2>Follow us</h2>
                <div class="social-icons">
                    <a href="#" class="fb"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="twt"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="insta"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright site-layout">
        <div class="container">
            <span>Copyright © 2018 All Rights Reserved</span>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Products</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
</footer>