<?php
$base_url = "http://dev.itcorporates.com/tokencms/";
?>
<header class="header">
    <div class="top-bar site-layout">
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <div class="top-left">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbartop" aria-controls="navbartop" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="lnr lnr-menu"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbartop">
                                <ul class="navbar-nav track">
                                    <li><span><a href="#"><img src="{{asset('public/images/icons-location.png')}}" alt="">Branch Locator</a></span></li>
                                    <li class="tel"><span><a href="#"><i class="phone-icon"><img src="{{asset('public/images/phone-icon.png')}}" alt=""></i>(+123) 123 - 456 - 789</a></span> </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
                <div class="col-sm-4 col-12">
                    <div class="social-icons float-right">
                        <a href="#" class="fb"><i class="fa fa-facebook"></i></a>
                        <a href="#" class="twt"><i class="fa fa-twitter"></i></a>
                        <a href="#" class="insta"><i class="fa fa-instagram"></i></a>
                    </div>
                    <div class="feedback-btn">
                        <button type="button"> Give Feedback </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="navigation site-layout">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="navbar-brand" href="{{$base_url}}">
                        <img src="{{asset('public/images/logo.svg')}}" alt="">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="lnr lnr-menu"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="{{$base_url.'same-day-dilivery/'}}">Home </a>
                            </li>
                            <li class="nav-item">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Services
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a href="#">Same day delivery</a></li>
                                    <li><a href="#">Products</a></li>
                                    <li><a href="#">Advantage</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Branch Locator
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a href="#">Branches </a></li>
                                    <li><a href="#">Delivery Area Coverage</a></li>
                                </ul>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="#">Become a Courier</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">FAQs</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Announcements</a></li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    About
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a href="#">About Adomton </a></li>
                                    <li><a href="#">Clients</a></li>
                                    <li><a href="#">Message from the CEO</a></li>
                                    <li><a href="#">Adomton Team</a></li>
                                    <li><a href="#">Career at Adomton</a></li>
                                </ul>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="#">Contact Us</a></li>
                        </ul>
                        <form class="form-inline my-2 my-lg-0">
                            <i class="fa fa-search"></i>
                        </form>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</header>
