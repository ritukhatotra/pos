<!doctype html>
<html>
@include('common.head')
<body>
    @include('common.top_navigation')
    @yield('content')
    @include('common.footer')
<script src="{{asset('public/js/jquery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('public/js/jquery.validate.min.js')}}" type="text/javascript"></script>
<script src="{{asset('public/js/common.js')}}" type="text/javascript"></script>
<script src="{{asset('public/js/respond.min.js')}}" type="text/javascript"></script>
<script src="{{asset('public/js/bootstrap.min.js')}}" type="text/javascript"></script>
<script src="{{asset('public/js/agent/agent.js')}}" type="text/javascript"></script>

</body>
</html>

