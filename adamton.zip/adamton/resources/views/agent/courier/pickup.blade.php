@extends('agent.main')
@section('content')
 <section class="courier-form-section site-layout section-padding">
            <div class="container">
                <div class="courier-form m-auto">
                    <form id="agent-reg-form" action="{{url('pickup-save')}}" method="post">
                        <input type="hidden" name="_token" value="{{csrf_token()}}"/>                        
                        <div class="form-group form-group-half">
                            <input type="text" name="FirstName" value="" placeholder="First Name" class="form-control">
                        </div>
						<div class="form-group form-group-half float-right">
                            <input type="text" name="LastName" value="" placeholder="Last Name" class="form-control">
                        </div>
						<div class="form-group form-group-half">
                            <input type="text" name="Mobile" value="" placeholder="Mobile" class="form-control">
                        </div>
						<div class="form-group form-group-half float-right">
                            <input type="text" name="HomeOffice" value="" placeholder="Home Office / Landline" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" name="address1" value="" placeholder="House No. / Street / Subdivision / Village" class="form-control">
                        </div>
						<div class="form-group">
                            <input type="text" name="address2" value="" placeholder="Address (Line 2" class="form-control">
                        </div>
						<div class="form-group">
                            <div class="select-box">
                                <select>
                                    <option value="">Select Area</option>
                                </select>
                                <span class="lnr lnr-chevron-down"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="ZipCode" value="" placeholder="Zip Code" class="form-control">
                        </div>
						
				<div class="form-group">
					<input type="text" name="Landmark/Notes" value="" placeholder="Landmark/Notes" class="form-control">
				</div>
                        <div class="form-group">
                            <input type="submit" value="Submit" />
                        </div>
                    </form>
                </div>
            </div>
        </section>
@stop