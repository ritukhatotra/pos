<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="{{ csrf_token() }}" />
    <title>{{$page_title}}</title>
    <link href="{{asset('public/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('public/css/style.css')}}" rel="stylesheet" type="text/css">
    <link rel="preconnect" href="//fonts.googleapis.com">
    <!--[if lt IE 9]>
    <script src="{{asset('public/js/html5shiv.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('public/js/respond.min.js')}}" type="text/javascript"></script>
    <![endif]-->
</head>
<body>
    <div class="login-page">
        <div class="middle-content">
            <div class="logo">
                <a href="http://dev.itcorporates.com/tokencms/">
                    <img src="{{asset('public/images/logo.svg')}}" alt="">
                </a>
            </div>
            <div class="login-form">
                <h3>Please login to your account.</h3>
                @if(session('err_message'))
                    <div class="alert alert-danger">
                        {{session('err_message')}}
                    </div>
                @endif
                <form id="login-form" action="{{url('agent/login')}}" method="post">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <input type="text" name="email" placeholder="Enter Email" value="" class="form-control" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" placeholder="Enter Password" value="" class="form-control" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" value="" name="remember_me">
                                <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                                Remember me
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Login" class="full-width">
                    </div>
                </form>
                <a href="{{url('agent-registration')}}">
                    <button class="full-width">Create New Account</button>
                </a>
                <p><a href="#" class="full-width">Forgot your password?</a>
                Don't worry! <a href="#">click here</a> To Reset</p>
            </div>
        </div>
    </div>
    <script src="{{asset('public/js/jquery.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('public/js/jquery.validate.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('public/js/common.js')}}" type="text/javascript"></script>
    <script src="{{asset('public/js/respond.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('public/js/bootstrap.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('public/js/agent/agent.js')}}" type="text/javascript"></script>
</body>
</html>