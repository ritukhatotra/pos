<!doctype html>
<html>
<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
    <?php echo $__env->make('common.top_navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="<?php echo e(asset('public/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('public/js/jquery.validate.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('public/js/common.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('public/js/respond.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('public/js/agent/agent.js')); ?>" type="text/javascript"></script>

</body>
</html>

