<?php $__env->startSection('content'); ?>
    <main>
        <section class="become-courier main-page-btns site-layout section-padding-70">
            <div class="container">
                <div class="section-title text-center m-b-0">
                    <h1>Driving With Adomton</h1>
                </div>
            </div>
        </section>
        <section class="courier-form-section site-layout section-padding">
            <div class="container">
                <div class="courier-form m-auto">
                    <form id="agent-reg-form" action="<?php echo e(url('agent-save')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                        <div class="form-group">
                            <div class="select-box">
                                <select name="country" id="country-select">
                                    <option value="">Which country would you like to drive:</option>
                                    <?php if(isset($countries)): ?>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country['id']); ?>"><?php echo e($country['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <span class="lnr lnr-chevron-down"></span>
                            </div>
                        </div>
                        <div class="form-group state-select select-hide">
                            <div class="select-box">
                                <select name="state" id="state-select">
                                </select>
                                <span class="lnr lnr-chevron-down"></span>
                            </div>
                        </div>
                        <div class="form-group city-select select-hide">
                            <div class="select-box">
                                <select name="city" id="city-select">
                                </select>
                                <span class="lnr lnr-chevron-down"></span>
                            </div>
                        </div>
                        <div class="form-group form-group-half">
                            <input type="text" name="name" value="" placeholder="Full Name" class="form-control">
                        </div>
                        <div class="form-group form-group-half float-right">
                            <input type="email" id="email" name="email" value="" placeholder="Email" class="form-control">
                            <span id="email-msg"></span>
                        </div>
                        <div class="form-group form-group-half">
                            <input type="text" id="uname" name="uname" value="" placeholder="Username" class="form-control">
                            <span id="username-msg"></span>
                        </div>
                        <div class="form-group form-group-half float-right">
                            <input type="password" name="password" value="" placeholder="Password" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" name="address" value="" placeholder="Address" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" id="mobile" name="mobile" value="" placeholder="Phone Number" class="form-control">
                            <span id="mobile-msg"></span>
                        </div>
                        <div class="form-group">
                            <h3>Terms and Conditions</h3>
                            <div class="checkbox">
                                <label style="font-size: 1em">
                                    <input type="checkbox" value="" name="check" checked=""/>
                                    <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                                    Please tick here to confirm that you have read and agree to our driver terms & conditions available at the below link
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <h3>Do you have the right to work as a self-employed contractor and have an Irish bank account?</h3>
                            <div class="radio">
                                <label style="font-size:1em">
                                    <input type="radio" name="o5" value="yes" checked />
                                    <span class="cr"><i class="cr-icon fa fa-circle"></i></span>
                                    Yes - UK, EU, EEA or Swiss Passport or Identity Card
                                </label>
                            </div>
                            <div class="radio">
                                <label style="font-size:1em">
                                    <input type="radio" name="o5" value="stamp 4" checked />
                                    <span class="cr"><i class="cr-icon fa fa-circle"></i></span>
                                    Stamp 4
                                </label>
                            </div>
                            <div class="radio">
                                <label style="font-size:1em">
                                    <input type="radio" name="o5" value="no" checked />
                                    <span class="cr"><i class="cr-icon fa fa-circle"></i></span>
                                    No
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Submit" />
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agent.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>