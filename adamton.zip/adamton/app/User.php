<?php
namespace App;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;
    protected $table = 'users';
    protected $fillable =['email','username','full_name','password','address1','mobile',
                        'address2','cities_id','states_id','countries_id','zip','user_roles_id','status',
                        'contract','created_at','updated_at','remember_token'];

    public static $rules = array(
        'username' => array('unique:users'),
        'email' => 'required|unique:users',
        'mobile' => 'unique:users'
    );

    protected $hidden = [
        'password', 'remember_token',
    ];

}
