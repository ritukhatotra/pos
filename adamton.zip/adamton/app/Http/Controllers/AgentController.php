<?php
namespace App\Http\Controllers;
use App\City;
use App\Country;
use App\State;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AgentController extends Controller
{
    /*
    ** Agent Registration
    */
    public function agentSignUp(){
        $data['page_title'] = "Adamton | Registration";
        $data['current_url'] = url()->current();
        $data['countries'] = Country::all();
        return view('agent.signup',$data);
    }

    /*
    ** get state
    */
    public function getState(Request $request) {
        $id = $request->get('cid');
        $states = State::where('country_id', $id)->get();
        echo '<option value="">Which state would you like to drive:</option>';
        foreach ($states as $state) {
            echo '<option value="'.$state['id'].'">'.$state['name'].'</option>';
        }
    }

    /*
    ** get city
    */
    public function getCity(Request $request) {
        $id = $request->get('sid');
        $cities = City::where('state_id', $id)->get();
        echo '<option value="">Which city would you like to drive:</option>';
        foreach ($cities as $city) {
            echo '<option value="'.$city['id'].'">'.$city['name'].'</option>';
        }
    }

    /*
    ** Agent Post Signup
    */
    public function agentPostSignUp(Request $request){
        $input = $request->all();
        if(isset($input)) {
            $user = new User();
            $user->email = $input['email'];
            $user->username = $input['uname'];
            $user->password = Hash::make($input['password']);
            $user->address1 = $input['address'];
            $user->mobile = $input['mobile'];
            $user->full_name = $input['name'];
            $user->user_roles_id = env('AGENT_USER');
            $user->contract = $input['o5'];
            $user->status = 'active';
            if($user->save()) {
                $pieces = explode(" ", $user->full_name);
                $fname = $pieces[0];
                $pwd = $input['password'];

                $url = "https://api.tookanapp.com/v2/add_agent";
                $data = array(
                        "api_key" => env('TOOKAN_API_KEY'),
                        "email" => $user->email,
                        "name" => $user->full_name,
                        "phone" => $user->mobile,
                        "transport_type" => "1",
                        "transport_desc" => "auto",
                        "license" => "demo",
                        "color" => "blue",
                        "timezone" => date('YYYY-MM-DD HH:I:S'),
                        "team_id" =>  env('TEAM_ID'),
                        "password" => $pwd,
                        "username" => $user->username,
                        "first_name" => $fname,
                );

                $payload = json_encode($data);

                $ch = curl_init( $url );
                curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
                curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
                curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
                curl_exec($ch);
                curl_close($ch);

                return redirect('agent/login');
            }
        }
    }

    /*
    ** Check email already exist
    */
    public function checkEmail(Request $request) {
        $email = $request->get('email');
        $user = User::where('email', $email)->first();
        if(isset($user)) {
            return "exist";
        }
        return "success";
    }

    /*
    **Check phone number already exist
    */
    public function checkPhone(Request $request) {
        $mobile = $request->get('mobile');
        $user = User::where('mobile', $mobile)->first();
        if(isset($user)) {
            return "exist";
        }
        return "success";
    }

    /*
    **Check username already exist
    */
    public function checkUsername(Request $request) {
        $uname = $request->get('uname');
        $user = User::where('username', $uname)->first();
        if(isset($user)) {
            return "exist";
        }
        return "success";
    }

    /*
    ** pickup
    */
    public function pickup() {
        if(Auth::user() == ''){
           return redirect('agent/login');
        }

        $data['page_title'] = "Adamton | Courier | Pickup";
        $data['current_url'] = url()->current();
        return view('agent.courier.pickup',$data);
    }
	
	/*
    ** pickup
    */ 
	
	public function pickupPostdata(Request $request){
        $input = $request->all();
		
        if(isset($input)) {
			$firstname = $input['FirstName'];
			$lastname  = $input['LastName'];
			$fullname  = $firstname.' '.$lastname;
			$user = new User();
			$user->full_name = $fullname;
			$user->mobile = $input['Mobile'];
			
			$user->address1 = $input['address1'];
			$user->address2 = $input['address2'];
			
            $user->zip = $input['ZipCode'];
			
            $user->password = Hash::make($input['password']);
            $user->user_roles_id = 3;
            $user->contract = $input['o5'];
            $user->status = 'active';

        }
    }
}