<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    /*
    ** Get Login
    */
    public function signin(){
        $data['page_title'] = "Adamton | Login";
        $data['current_url'] = url()->current();
        return view('agent.auth.signin',$data);
    }

    /*
    ** post login
    */
    public function postSignIn(Request $request) {
        $input = $request->all();
        if(isset($input)) {
            $rules = array( 'email' => 'required', 'password' => 'required');
            $v = Validator::make( $input, $rules );
            if($v->passes()) {
                $credentials = array('email' => $input['email'], 'password' => $input['password']);

                if ( Auth::attempt($credentials, true) ) {
                    Session::put('userinfo.id', Auth::user()->id);
                    return redirect( 'courier/pickup' );
                } else {
                    $request->session()->flash('err_message', 'Wrong Credentails!!');
                    return redirect( 'agent/login' );
                }
            } else {
                $request->session()->flash('err_message', 'Please Fill correct fields!!');
                return redirect( 'agent/login' );
            }
        }
    }

    /*
    ** logout
    */
    public function logout() {
        Auth::logout();
        return redirect( 'agent/login' );
    }
}