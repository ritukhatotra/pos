<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/* agent */
Route::get('agent/login','AuthController@signin');
Route::post('agent/login','AuthController@postSignIn');
Route::get('logout','AuthController@logout');
Route::get('agent-registration','AgentController@agentSignUp');
Route::post('agent-save','AgentController@agentPostSignUp');
Route::post('get-state','AgentController@getState');
Route::post('get-city','AgentController@getCity');
Route::post('check-email','AgentController@checkEmail');
Route::post('check-username','AgentController@checkUsername');
Route::post('check-phone','AgentController@checkPhone');

/* courier pickup */
Route::get('courier/pickup','AgentController@pickup');
Route::post('pickup-save','AgentController@pickupPostdata');



