<form action="home/save" method="post">
    <input type="file" name="profile_photo"/>
    <input type="submit" value="upload"/>
</form>