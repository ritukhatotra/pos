<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>{{$page_title}}</title>
	<link rel="icon" href="{{asset('public/images/fav-icon.png')}}" type="image/gif" sizes="16x16">
	<link href="{{asset('public/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
	<link href="{{asset('public/css/style.css')}}" rel="stylesheet" type="text/css">
</head>
<body>
<header class="header">
	<div class="container">
    	<div class="logo">
        	 <a href="#"> <img src="{{asset('public/images/logo.png')}}" alt=""></a>
        </div>
    </div>
</header>
<div class="form-section">
	<div class="container">
    	<div class="col-sm-6 col-sm-offset-3">
        	<form id="forget-password-form" action="{{url('api/get-password')}}" method="post">
        		<input type="hidden" name="_token" value="{{csrf_token()}}"/>
				<input type="hidden" name="id" value="{{$id}}"/>
            	<div class="form-group">
                	<input type="password" id="password" name="password" placeholder="Password" value="" class="form-control">
                </div>                
                <div class="form-group">
                	<input type="password" name="confirmPassword" placeholder="Confirm Password" value="" class="form-control">
                </div>                
                <div class="form-group">
                	<input type="submit" value="Submit" class="submit-btn"/>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.min.js"></script>
<script src="{{asset('public/js/bootstrap.min.js')}}" type="text/javascript"></script>
<script>
jQuery(function() {
	jQuery("#forget-password-form").validate({
		rules: {
			password: {
				required: true,
			},
			confirmPassword: {
				required:true,
				equalTo: "#password"
			}
		},
		submitHandler: function(form) {
			form.submit();
		}
	});
});
</script>
</body>
</html>
