<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Notifications\Notifiable;
// use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Model
{
    /**
    * The table associated with the model.
    *
    * @var string
    */
    protected $table = 'tguy_users';

    // use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable =['user_login','user_email','user_pass','user_role','created_at','updated_at'                 , 'email_token', 'token_expiry'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
       'remember_token'
    ];
}
