<?php 
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\UserMeta;
use App\Product;
use App\ProductDetail;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;

class ApiController extends Controller
{
	public function home() {
		echo "hello ".env('APP_URL');
		// return view('api.home');
	}

	/*
	** Signup
	*/
	public function signup(Request $request) {
		$input = $request->all();		
		if(isset($input)){
			if($input['email'] != '' && $input['password'] != '' &&
			   $input['name'] != '' && $input['contact_number'] != '' && $input['address'] != '') {

				$email = $input['email'];
				$checkUser = User::where('user_email', $email)->first();
				
				if(isset($checkUser)){
					$ret = array('status' => 0, 'message' => 'User already exist!! Please Try another');
				} else {	
					$user = new User();
					$user->user_email = $input['email'];
					$user->user_pass = md5($input['password']);
					$user->user_role = 'customer';	
					if($user->save()) {
						$userMeta = new UserMeta();
						$userMeta->address = $input['address'];
						$userMeta->name = $input['name'];
						$userMeta->contact_number = $input['contact_number'];
						$userMeta->user_id = $user->id;
						/*if(isset($input['profile_photo'])){
							$imageName = $user->id.'_'.$request->file('profile_photo')->getClientOriginalExtension();

						    $request->file('image')->move(
						        env('APP_URL').'/public/images/user'.$imageName
						    );

							$userMeta->profile_photo = $input['profile_photo'];	
						}	*/
						if($userMeta->save()){
							$data['name'] = $userMeta->name;
							$data['email'] = $user->user_email;
							$data['address'] = $userMeta->address;
							$data['contact_number'] = $userMeta->contact_number;
							$data['profile_photo'] = $userMeta->profile_photo;
							$ret = array('status' => 1, 'message' => 'User successfully added.', 'data' => $data);
						}
					} else {
						$ret = array('status' => 0, 'message' => 'Something went wrong.');
					}		
				}
			} else {
				$ret = array('status' => 0, 'message' => 'All fields are mandatory');
			}
		} else {
			$ret = array('status' => 0, 'message' => 'All fields are mandatory');
		}
		print_r(json_encode($ret));
	}

	/*
	** signin
	*/
	public function signin(Request $request) {
		$input = $request->all();
		if(isset($input)){
			if($input['email'] != '' && $input['password'] != '') {
				$user = User::where('user_email',$input['email'])
						->where('user_pass', md5($input['password']))
						->where('user_role', 'customer')
						->first();

				if(isset($user)){
					$data['user_id'] = $user['ID'];
					$data['email'] = $user['user_email'];

					$userMeta = UserMeta::where('user_id',$user['ID'])->first();
					if(isset($userMeta)){
						$data['name'] = $userMeta['name'];				
						$data['address'] = $userMeta['address'];
						$data['contact_number'] = $userMeta['contact_number'];
						$data['profile_photo'] = $userMeta['profile_photo'];
					}

					$ret = array('status' => 1, 'message' => 'Login successfully.', 'data' => $data);
				} else {
					$ret = array('status' => 1, 'message' => 'Wrong email or password.');
				}				
				
			} else {
				$ret = array('status' => 0, 'message' => 'All fields are mandatory');
			}
		} else {
			$ret = array('status' => 0, 'message' => 'All fields are mandatory');
		}

		print_r(json_encode($ret));
	}

	/*
	** product List
	*/
	public function productList() {
		$result = array();
		$imageUrl = 'http://dev.itcorporates.com/thecomputerguywp/wp-content/uploads/';
		$dummyImageUrl = "http://dev.itcorporates.com/thatComputerGuy_mob/api/public/images/product/dummy-product.jpg";

		$products = Product::where('post_type', 'product')->get();
		if(isset($products)) {
			foreach ($products as $product) {
				$productDetail = ProductDetail::where('post_id', $product['ID'])->where('meta_key', '_price')->first();
				 
				$data['prod_id'] = $product['ID'];
				$data['prod_title'] = $product['post_title'];
				$data['prod_description'] = $product['post_content'];

				if(isset($productDetail)) {
				 	$data['prod_price'] = $productDetail['meta_value'];				
				} else {
					$data['prod_price'] = '';
				}

				$getImageKey = ProductDetail::where('post_id', $product['ID'])->where('meta_key', '_thumbnail_id')->first();

				if(isset($getImageKey)) {
					$getImageVal = ProductDetail::where('post_id', $getImageKey['meta_value'])
								->where('meta_key', '_wp_attached_file')->first();

					if(isset($getImageVal)) {
						$data['prod_image'] = $imageUrl.$getImageVal['meta_value'];
					} else {
						$data['prod_image'] = $dummyImageUrl;
					}
				} else {
					$data['prod_image'] = $dummyImageUrl;
				}				

				$result[] = $data;
			}

			$ret = array('status' => 1, 'message' => 'Products List.', 'data' => $result);
		} else {
			$ret = array('status' => 1, 'message' => 'No result found.', 'data' => $result);
		}

		print_r(json_encode($ret));
	}

	/*
	** forgot password
	*/
	public function forgotPassword(Request $request) {
		$input =$request->all();
		if(isset($input)) {
			if($input['email'] != '') {
				$checkUser = User::where('user_email', $input['email'])->first();
				if(isset($checkUser)) {
			  		$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
				    $charsLength = strlen($chars);
				    $randomString = '';
				    $length = 20;
				   
				    for ($i = 0; $i < $length; $i++) {
				        $randomString .= $chars[rand(0, $charsLength - 1)];
				    }

					$userId =  Crypt::encrypt($checkUser['ID']);
					$token =  $randomString;
					$currentTime = strtotime(date('Y-m-d H:i:s', time()));				
					$expiryTime =  $currentTime + 3600;
					$extractName = explode("@", $input['email']);
					$username = $extractName[0];
					if($expiryTime >= $currentTime) {
						$link = env('APP_URL').'verify-link?token='.$token.'&uid='.$userId;
						$this->sendForgotPasswordMail($username, $input['email'], $link);
					} else {
						echo "link expired";
					}

					$ret = array('status' => 1, 'message' => 'Email has successfully sent. Please check your email inbox/spam messages.');
				} else {
					$ret = array('status' => 0, 'message' => 'Email not found.');
				}
			} else {
				$ret = array('status' => 0, 'message' => 'Email is required.');
			}
		} else {
			$ret = array('status' => 0, 'message' => 'Email is required.');
		}

		print_r(json_encode($ret));
	}

	/*
	** send forgot password mail
	*/
	public function sendForgotPasswordMail($username = NULL, $email = NULL, $link = NULL) {
		$to = $email;
		$subject = "Forgot Password";
		$txt = '<p>Hello '.ucfirst($username).',</p>';
		$txt .= '<p>To change your password click on <strong>Click Here</strong>. Your link is expire after 1 hour.</p><br/>';
		$txt .= '<a href="'.$link.'" target="_blank">Click Here</a>';
		$txt .= '<p>Thanks</p>';
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= "From: ritu.itcorporates@gmail.com";

		mail($to,$subject,$txt,$headers);
	}

	/* 
	** forgot password link
	*/
	public function forgotPasswordLink($uid=NULL, Request $request) {
		$data['page_title'] = 'That Computer Guy | Forgot Password';
		$data['id'] = $request->input('uid');
		return view('api.forgotPassword', $data);		
	}

	/* 
	** get password
	*/
	public function getPassword(Request $request) {
		$input = $request->all();
		$id = Crypt::decrypt($input['id']);
		$payload = array('user_pass' => md5($input['password']));
		$update = User::where('ID', $id)->update($payload);
		if($update) {
			return redirect('api/forgotPassword/success');
		}
	}

	/* 
	** success
	*/
	public function successMessage() {
		$data['page_title'] = 'That Computer Guy | Forgot Password | Success';
		return view('api.successMessage',$data);
	}

	/* 
	** about 
	*/
	public function about() {
		$data['heading1'] = "Customer Support";
		$data['heading1-description'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";

		$data['heading2'] = "Profeshional & Warranty";
		$data['heading2-description'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";

		$data['main-description'] = "That Computer Guy Inc. has been serving the Waterloo regional community for six years. We’ve maintained a strong commitment to offering fast, inexpensive computer repair service and helping home users and businesses with their computer needs. We work on your computers as if they were our own, and give you honest answers and smart solutions to get you back up and running.That Computer Guy Inc. has been serving the Waterloo regional community for six years. We’ve maintained a strong commitment to offering fast, inexpensive computer repair service and helping home users and businesses with their computer needs.";

		$ret = array('status' => 1, 'message' => 'About Us', 'data' => $data);
		print_r(json_encode($ret));
	}
}
?>