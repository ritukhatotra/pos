<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'tguy_posts';

    protected $fillable = ['post_title','post_type','post_content'];
}
