<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo e($page_title); ?></title>
	<link rel="icon" href="<?php echo e(asset('public/images/fav-icon.png')); ?>" type="image/gif" sizes="16x16">
	<link href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('public/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>
<body>

    <div class="form-section">
        <div class="middle-content">
        <div class="container">
            <div class="logo">
                <a href="#"><img src="<?php echo e(asset('public/images/logo.png')); ?>" alt="" /></a>
            </div>
                <?php if(session('msg')): ?>
                    <div class="col-sm-4 col-sm-offset-4">
                        <div class="alert alert-danger">
                            <?php echo e(session('msg')); ?>

                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-sm-4 col-sm-offset-4">
                        <form id="forget-password-form" action="<?php echo e(url('api/get-password')); ?>" method="post">
                            <h3>Forgot Password</h3>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                            <div class="form-group">
                                <input type="password" id="password" name="password" placeholder="Password" value="" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="password" name="confirmPassword" placeholder="Confirm Password" value="" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="submit" value="Submit" class="submit-btn"/>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.min.js"></script>
<script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script>
jQuery(function() {
	jQuery("#forget-password-form").validate({
		rules: {
			password: {
				required: true,
			},
			confirmPassword: {
				required:true,
				equalTo: "#password"
			}
		},
		submitHandler: function(form) {
			form.submit();
		}
	});
});
</script>
</body>
</html>
