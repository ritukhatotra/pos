<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo e($page_title); ?></title>
    <link href="<?php echo e(asset('public/css/all.css')); ?>" rel="stylesheet" type="text/css">
</head>