@if($current_url == env('APP_URL').'admin/new-customer')
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="{{url('admin/dashboard')}}">Dashboard</a>
        <a href="{{url('admin/customers')}}">Customers</a>
        <a href="{{url('admin/new-custmer')}}">New Customer</a>
    </div>
@elseif($current_url == env('APP_URL').'admin/customers')
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="{{url('admin/dashboard')}}">Dashboard</a>
        <a href="{{url('admin/customers')}}">Customers</a>
    </div>
@elseif($current_url == env('APP_URL').'admin/customer/edit/'.Request::segment(4))
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="{{url('admin/dashboard')}}">Dashboard</a>
        <a href="{{url('admin/customers')}}">Customers</a>
        <a href="{{url('admin/customer/edit').'/'.Request::segment(4)}}">Edit Customer</a>
    </div>
@else
    <div class="nav navbar-nav top-elements navbar-breadcrumb hidden-xs">
        <a href="{{url('admin/dashboard')}}">Dashboard</a>
    </div>
@endif
