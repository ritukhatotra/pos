<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/* admin login*/
Route::get('/','AdminController@getSignin');
Route::get('login','AdminController@getSignin');
Route::post('admin/signin','AdminController@postSignin');
Route::get('admin/dashboard','AdminController@dashboard');
Route::get('admin/logout','AdminController@logout');
/* customer */
Route::get('admin/new-customer','CustomerController@newCusotmer');
Route::get('admin/customers','CustomerController@cusotmerList');
Route::post('ajax/getState','AjaxController@getState');
Route::post('ajax/checkCustomerPhone','AjaxController@checkCustomerPhone');
Route::post('ajax/checkCustomerEmail','AjaxController@checkCustomerEmail');
Route::post('ajax/checkCustomerAccount','AjaxController@checkCustomerAccount');
Route::post('save-customer','CustomerController@saveCusotmer');
Route::get('admin/customer/edit/{id}','CustomerController@editCustomer');
Route::post('update-customer','CustomerController@updateCusotmer');
Route::get('admin/customer/deleteProfilePhoto/','CustomerController@deleteProfilePhoto');
Route::post('ajax/search-customer','AjaxController@searchCustomer');
Route::post('ajax/show-search-customer','AjaxController@displayCustomer');
