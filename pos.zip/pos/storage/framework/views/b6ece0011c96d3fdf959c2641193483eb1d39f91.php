<!doctype html>
<html>
<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
    <div class="wrapper sales-bar mini-bar">
        <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content" id="content">
            <?php echo $__env->make('common.top_navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <div id="footers" class="col-md-12 hidden-print text-center"> Please visit our <a href="#">Website</a> to learn the latest information about the project.
                <span class="text-info">
                    You are using PHP Point Of Sale Version
                    <span class="badge bg-primary"> 16.2</span>
                </span>
                Built on 07/15/2018 12:23 pm EST
            </div>
        </div>
    </div>
<script src="<?php echo e(asset('public/js/all.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/admin/admin.js')); ?>"></script>
</body>
</html>

