<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo e($page_title); ?></title>
	<link href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('public/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="form-section">
		<div class="middle-content">
			<div class="container">
				<div class="logo">
					<a href="#"><img src="<?php echo e(asset('public/images/logo.png')); ?>" alt="" /></a>
				</div>
				<div class="col-sm-4 col-sm-offset-4">
					<form>
						<p class="alert alert-success success-pwd">Password has successfully changed.</p>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
