-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 09, 2018 at 11:41 AM
-- Server version: 10.2.16-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itcorporates_mohali_homeservices`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `booking_date` bigint(20) NOT NULL,
  `booking_time` bigint(20) NOT NULL,
  `type` enum('electrician','plumber','painter','tank-cleaner') NOT NULL,
  `job_status` varchar(30) NOT NULL DEFAULT 'pending',
  `is_invoice` varchar(30) NOT NULL DEFAULT 'no invoice',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `phone_number`, `booking_date`, `booking_time`, `type`, `job_status`, `is_invoice`, `created_at`, `updated_at`) VALUES
(1, 1, -1934044615, 1531872000, 1532001480, 'electrician', 'pending', 'no invoice', '2018-07-19 07:26:21', '2018-07-19 07:26:21'),
(2, 1, -1934044615, 1532304000, 1532347080, 'tank-cleaner', 'pending', 'no invoice', '2018-07-23 06:58:05', '2018-07-23 06:58:05'),
(3, 8, 7986794042, 1532649600, 1532437500, 'plumber', 'pending', 'no invoice', '2018-07-24 09:30:38', '2018-07-24 09:30:38'),
(4, 8, 7986794042, 1532736000, 1532456700, 'electrician', 'pending', 'no invoice', '2018-07-24 09:52:20', '2018-07-24 09:52:20'),
(5, 8, 7986794042, 1532736000, 1532431800, 'tank-cleaner', 'pending', 'no invoice', '2018-07-24 09:59:29', '2018-07-24 09:59:29'),
(6, 8, 7837619829, 1531440000, 1532442960, 'plumber', 'pending', 'no invoice', '2018-07-24 10:06:09', '2018-07-24 10:06:09'),
(7, 11, 645321789, 1532822400, 1532617200, 'electrician', 'pending', 'no invoice', '2018-07-26 11:18:37', '2018-07-30 09:04:28'),
(8, 11, 1234564890, 1532649600, 1532631000, 'tank-cleaner', 'cancelled', 'no invoice', '2018-07-26 11:20:39', '2018-07-30 09:10:35'),
(9, 11, 798679, 1535068800, 1533309120, 'painter', 'pending', 'no invoice', '2018-08-03 07:42:53', '2018-08-03 07:42:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `contact_number` bigint(20) NOT NULL,
  `address` text NOT NULL,
  `profile_photo` varchar(100) DEFAULT NULL,
  `user_roles_id` int(11) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `remember_token` varchar(300) DEFAULT NULL,
  `otp` bigint(20) DEFAULT NULL,
  `otp_expiry_time` bigint(20) DEFAULT NULL,
  `email_token` varchar(300) DEFAULT NULL,
  `token_expiry_time` bigint(20) DEFAULT NULL,
  `device_token` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact_number`, `address`, `profile_photo`, `user_roles_id`, `status`, `remember_token`, `otp`, `otp_expiry_time`, `email_token`, `token_expiry_time`, `device_token`, `created_at`, `updated_at`) VALUES
(1, 'ritu', 'ritu@gmail.com', '$2y$10$eJae5GSw3mdsB6nZSmqDdulUlFAtkIbh4pfjQjewvzOF/44nRScV.', 9876543210, 'mohali', NULL, 2, 'active', 'Rnt1vWkiFZmRRgRsaor5hYoEDsXgP3WKTqz9fycx4A9y7NZhJ83sEPSGhRbf', NULL, NULL, NULL, NULL, NULL, '2018-07-12 11:01:09', '2018-07-12 11:01:09'),
(2, 'ritu', 'ritu.itcorporates@gmail.com', '$2y$10$.Cs6Yt9YmjG73nshSVCbJOMY7YlNEAw3HzpO0gHcBX6FS/rS6GVXy', 9876543200, 'mohali', 'Arjun_861553972.jpg 	', 2, 'active', 'LrZJ5BjqPbv6UZPktFLeMVXljU9W4kGUbsONynxWv3yF7HPeZsYJ5XF4iMK5', NULL, NULL, '9P7ItoK7O4J8GaWxuK5r', 1531736043, 'aerererbc34fsf34535', '2018-07-12 11:06:16', '2018-07-25 10:00:47'),
(3, 'seerat', 'test1@gmail.com', '$2y$10$uPXZ2Tvn.Xtj7TLjQbRz2ux9jK2/U1rfxQe9qllBRUWXHIetzy7wC', 9988776656, 'mohali', NULL, 2, 'active', '4DqV2oVw5S3OeAsjtz1gq8yynd7MaCKR1ZESsBODxdV3C9iyjDh80RtOd6QQ', NULL, NULL, NULL, NULL, NULL, '2018-07-12 11:38:09', '2018-08-02 11:06:27'),
(4, 'Ashish Kumar', 'ashish.itcorporates@gmail.com', '$2y$10$hxLTZqWDEsXpyTPax72x5ex62zw4xLqndVfICNnIwDMzkAiMGnboC', 7307607585, 'E-196, Phase 8B, Industrial Area, Sector 74, Sahibzada Ajit Singh Nagar, Punjab 140308, India', NULL, 2, 'active', NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-13 06:32:14', '2018-07-13 06:32:14'),
(5, 'sona', 'sona@gmail.com', '$2y$10$CJRgbbc755waq7zW7M7Y2e4lyttBjXPnBFbhVKApZorueQcD.1o3K', 7788996655, 'Chandigarh', NULL, 2, 'active', NULL, 7658, 1531477049, 'ldrLbeLuW4uhpSxIrl7e', 1531735886, NULL, '2018-07-13 07:44:29', '2018-07-16 09:11:26'),
(6, 'Ashu', 'ashuluv18@gmail.com', '$2y$10$UzYzJ0wJHgMqLesIxbGX7ucXdPLLsimp.8hMffzncWQ1v3fKEvdgm', 7986794042, 'E-196, Phase 8B, Industrial Area, Sector 74, Sahibzada Ajit Singh Nagar, Punjab 140308, India', NULL, 2, 'inactive', NULL, 7186, 1531487165, NULL, NULL, NULL, '2018-07-13 12:36:05', '2018-07-13 12:36:05'),
(7, 'Saurabb', 'saurabh.itcorporates@gmail.com', '$2y$10$DUtnrFruchE9D.fuGR27P.NMi0qNEEVYxgUZPeU7MSfe89vi16tey', 7837619828, 'E-196, Phase 8B, Industrial Area, Sector 74, Sahibzada Ajit Singh Nagar, Punjab 140308, India', NULL, 2, 'active', 'n6VS6rQWziv3d0tSZMhNMczYlSexJoFtRkKV1MbTUft3bM9bP0Lj89OBceQW', 7586, 1531829135, NULL, NULL, NULL, '2018-07-17 11:35:35', '2018-07-17 11:36:00'),
(8, 'Beckon', 'rockingashu1388@gmail.com', '$2y$10$0sP36zhOHYYJrymNdzbuV.Q/0AfTG3AqYzsfQyWW/TEANoLvdUq6q', 8557807921, 'E-196, Phase 8B, Industrial Area, Sector 74, Sahibzada Ajit Singh Nagar, Punjab 140308, India', NULL, 2, 'active', 'fQMmcRezCsP8sZyOUBeRpTfS9aXRA5EVKDuHONeKpWmsHQ6jfaHFB9aZmDkg', 3456, 1531987077, NULL, NULL, 'fN3u3Or-4TY:APA91bEG7MKVKKH-qeVSy1iF7QfpfuCThschjqwjdz4okfmRDSHLDhjaISgxA3lT9HN1NxgwTrM7Tzt9Kig0wSt0oF80PG4Xxr1SanF7_eMirTEZZYPKyq_CB2wUvHzsNeONrNX10jGbtxWamj9jVaNqQq7YOZNAyg', '2018-07-19 07:27:57', '2018-07-23 06:29:42'),
(9, 'Ashu', 'ashuluv@gmail.com', '$2y$10$/tZiQGF0vNAugFTbRwxZbugDMwKbgVKpPsw4r6aNHYPbNgYJMfS3.', 7654398321, 'E-196, Phase 8B, Industrial Area, Sector 74, Sahibzada Ajit Singh Nagar, Punjab 140308, India', NULL, 2, 'inactive', NULL, 5669, 1532512787, NULL, NULL, NULL, '2018-07-25 09:29:47', '2018-07-25 09:29:47'),
(10, 'dk', 'dk@gmail.com', '$2y$10$/yWyqS59ZWB4upqvGeB4/uQ/uIsCrpmJgXJCHOYlh4P4t1qOeC9g.', 6453128796, 'E-196, Phase 8B, Industrial Area, Sector 74, Sahibzada Ajit Singh Nagar, Punjab 140308, India', NULL, 2, 'active', NULL, 3694, 1532513065, NULL, NULL, NULL, '2018-07-25 09:34:25', '2018-07-25 09:38:01'),
(11, 'Arjun Kapoor', 'arjun@gmail.com', '$2y$10$/HD6lGNpL49I.HsjjzrZ6eRX3TgPzXH4puMuGzJJ0DKbNxlDjwO16', 3124567976, 'E-196, Phase 8B, Industrial Area, Sector 74, Sahibzada Ajit Singh Nagar, Punjab 140308, India', 'Arjun_861553972.jpg', 2, 'active', 'ri77Ib4EvqSnNqrfNA5HD1wnQZTdIi0WdNls06pzgkwerveCgoLPAU995evQ', 5967, 1532513915, NULL, NULL, 'fSXKqLy6w78:APA91bGcjpzo9s1L-DKEeOz7cMWd5XWJDscKWCcjTCKvXCpeNkhll8B7Gwfp7Vn0RO3S67o4cm57G7T8qewrcF8mIzDe0eDg_RXvdA8Ib_6IQaEq1kt0CZcdbdawPtSyKU6XO7xEwaakrAX9FY53ppmKV84O-aXhpg', '2018-07-25 09:48:35', '2018-08-03 09:01:59'),
(13, 'plumber', 'plumber@mohaliservice.com', '$2y$10$xzVvq87EOVeKaXnPs9i2AeXYF7jFffYPBpAd5NDUaG6FHKp5WB3BW', 9988776655, 'mohali', NULL, 3, 'active', 'tvDj2m2zVD8eGAb1dsAJdakBB31h5P8lEloiIXmUj1XtmzWLJo77BxPWDxmR', NULL, NULL, NULL, NULL, 'jfkfkskjdfks57657867698', '2018-08-06 15:00:37', '2018-08-06 09:49:09'),
(14, 'electrician', 'electrician@mohaliservice.com', '$2y$10$zL0ZTVErh1RnEAhbdDGHUudEUVRgyvQeWWJQ0e7C1tPtfI/FCw.hq', 8877665544, 'mohali', NULL, 4, 'active', 'TU30Q5x5If9pHjZS1C9uMSMiHl56nvFRZTQ4k6JE2uIDqe3HNYgeOMOcUMz5', NULL, NULL, NULL, NULL, 'jfkfkskjdfks57657867698', '2018-08-06 15:01:58', '2018-08-06 09:47:03'),
(16, 'tank cleaner', 'tankcleaner@mohaliservice.com', '$2y$10$7Oue2jJtDszGY2jwE8SgIeX6wjw96lHbwWwlm1r0WNd8ZApnVHpvO', 7766554433, 'mohali', NULL, 5, 'active', 'kFSCWdo38bw6vYoT1u2ZbzmCam1hU8WZx1RFKJLKFYWtjxqHpLgAmGBTuQkC', NULL, NULL, NULL, NULL, 'jfkfkskjdfks57657867698', '2018-08-06 15:05:18', '2018-08-06 09:47:47'),
(17, 'painter', 'painter@mohaliservice.com', '$2y$10$A9G5MnjRojHAoookyYvCgOekV3GKLWkgjx9y9dTIuDSXoqbE85AoO', 6655443322, 'mohali', NULL, 6, 'active', 'Smw45qdGvLE3CuxyIDn3rVHhVxMtB9UiaXMFEP3cgE20UIgRc6eCWDeWtDFz', NULL, NULL, NULL, NULL, 'jfkfkskjdfks57657867698', '2018-08-06 15:06:42', '2018-08-06 09:48:34');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `name`) VALUES
(1, 'admin'),
(4, 'electrician'),
(6, 'painter'),
(3, 'plumber'),
(5, 'tank-cleaner'),
(2, 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `contact_number` (`contact_number`),
  ADD KEY `user_roles_id` (`user_roles_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`user_roles_id`) REFERENCES `user_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
