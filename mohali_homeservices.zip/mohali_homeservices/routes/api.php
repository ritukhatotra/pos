<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

/*Route::get('products', 'ProductsController@index');
Route::get('products/{product}', 'ProductsController@show');
Route::post('products','ProductsController@save');
Route::put('products/{product}','ProductsController@update');
Route::delete('products/{product}', 'ProductsController@delete');*/

Route::post('signup','ApiController@postSignup');
Route::post('signin','ApiController@postSignIn');
Route::post('verify-otp','ApiController@verifyOtp');
Route::post('resend-otp','ApiController@resendOtp');
Route::post('forgot-password','ApiController@forgotPassword');
Route::post('get-password', 'ApiController@getPassword');
Route::get('forgotPassword/success', 'ApiController@successMessage');
Route::post('booking', 'ApiController@booking');
Route::post('user-booking-history', 'ApiController@getBookingById');



