<?php

namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;
    protected $table = 'users';
    protected $fillable =['name','email','password','address','contact_number','user_roles_id',
                        'status','otp','otp_expiry_time','remember_token','email_token','token_expire_time',
                        'created_at','updated_at','device_token','profile_photo'];

    public static $rules = array(
        'name' => 'required',
        'email' => 'required',
        'password' => 'required',
        'contact_number' => 'required',
        'address' => 'required'
    );

    protected $hidden = [
        'password', 'remember_token'
    ];

    /**
     * bookings for specific user.
     */
    public function booking()
    {
        return $this->belongsTo('App\Booking');
    }
}
