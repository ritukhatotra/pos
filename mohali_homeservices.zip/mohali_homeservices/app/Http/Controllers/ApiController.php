<?php

namespace App\Http\Controllers;

use App\Booking;
use App\User;
use App\User_Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class ApiController extends Controller
{
    /*
    ** Sign Up
    */
    public function postSignup(Request $request)
    {
        $input = $request->all();
        $v = Validator::make($input, User::$rules);
        if ($v->passes()) {
            $name = $input['name'];
            $email = $input['email'];
            $contact = $input['contact_number'];
            $contactLength = strlen((string)$contact);

            /* check location */
            if (!isset($input['lat']) || !isset($input['lng'])) {
                return json_encode(array('status' => 0, 'message' => 'Kindly on your Location OR GPS'));
            }

            /*check valid phone number */
            if (!is_numeric($contact)) {
                return json_encode(array('status' => 0, 'message' => 'Only number allowed.'));
            }

            if (($contactLength != 10)) {
                return json_encode(array('status' => 0, 'message' => 'Enter 10 digit mobile number.'));
            }

            /* check valid email */
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return json_encode(array('status' => 0, 'message' => 'Enter valid email address.'));
            }

            /* check valid name */
            if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
                return json_encode(array('status' => 0, 'message' => 'Only characters allowed.'));
            }

            /* check email already exist */
            $existEmail = User::where('email', $email)->first();
            if (isset($existEmail)) {
                return json_encode(array('status' => 0, 'message' => 'Email already exist.'));
            }

            /* check contact number already exist */
            $existContactNumbwer = User::where('contact_number', $contact)->first();
            if (isset($existContactNumbwer)) {
                return json_encode(array('status' => 0, 'message' => 'Contact Number already exist.'));
            }

            /* check service available */
            /* check in mohali */
            $mohali = null;
            $serviceMohali = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBUcIApnoBk4aLtzr4P3zWBeEKqun0oGzU&latlng=' . $input['lat'] . ',' . $input['lng']);
            $serviceMohali = json_decode($serviceMohali);
            if (isset($serviceMohali)) {
                $mohaliAddress = $serviceMohali->results[0]->address_components;
                foreach ($mohaliAddress as $key) {
                    if ($key->long_name == "Sahibzada Ajit Singh Nagar") {
                        $mohali = $key->long_name;
                    }
                }
            }

            /* check in chandigarh */
            $chandigarh = null;
            $serviceChd = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBUcIApnoBk4aLtzr4P3zWBeEKqun0oGzU&latlng=' . $input['lat'] . ',' . $input['lng']);
            $serviceChd = json_decode($serviceChd);
            if (isset($serviceChd)) {
                $chdAddress = $serviceChd->results[0]->address_components;
                foreach ($chdAddress as $key) {
                    if ($key->long_name == "Chandigarh") {
                        $chandigarh = $key->long_name;
                    }
                }
            }

            /* check in kharar */
            $kharar = null;
            $serviceKhr = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBUcIApnoBk4aLtzr4P3zWBeEKqun0oGzU&latlng=' . $input['lat'] . ',' . $input['lng']);
            $serviceKhr = json_decode($serviceKhr);
            if (isset($serviceKhr)) {
                $khrAddress = $serviceKhr->results[0]->address_components;
                foreach ($khrAddress as $key) {
                    if ($key->long_name == "Kharar") {
                        $kharar = $key->long_name;
                    }
                }
            }

            if ($mohali == null && $chandigarh == null && $kharar == null) {
                return json_encode(array('status' => 0, 'message' => 'Service Unavailable.'));
            }
            /*end services*/
            /* OTP */
            $numbers = '0123456789';
            $numbersLength = strlen($numbers);
            $randomNumber = '';
            $length = 4;
            for ($i = 0; $i < $length; $i++) {
                $randomNumber .= $numbers[rand(0, $numbersLength - 1)];
            }

            $currentTime = strtotime(date('Y-m-d H:i:s'));
            $expiryTime = strtotime("+30 minutes", $currentTime);

            /* save data into users table */
            $user = new User();
            $user->name = $name;
            $user->email = $email;
            $user->password = Hash::make($input['password']);
            $user->contact_number = $contact;
            $user->address = $input['address'];
            $user->user_roles_id = env('USER_ROLE');
            $user->status = env('USER_STATUS_INACTIVE');
            $user->otp = $randomNumber;
            $user->otp_expiry_time = $expiryTime;
            if ($request->file('profile_photo')) {
                $file = $request->file('profile_photo');

                $name = $input['name'].'_'.rand() . '.' . $file->getClientOriginalExtension();
                $file->move('./public/uploads', $name);
                $user->profile_photo = $name;
            }
            if ($user->save()) {
                $data['email'] = $user->email;
                $data['otp'] = $user->otp;
                $ret = array('status' => 1, 'message' => 'Signup successfully.', 'data' => $data);
            } else {
                $ret = array('status' => 0, 'message' => "Whoop's, Something went wrong. Please try again.");
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Please fill all field.');
        }

        print_r(json_encode($ret));
    }

    /*
    ** post login
    */
    public function postSignIn(Request $request)
    {
        $input = $request->all();
        $rules = array('email' => 'required', 'password' => 'required', 'device_token' => 'required');
        $v = Validator::make($input, $rules);
        if ($v->passes()) {
            $checkUserStatus = User::where('email', $input['email'])->where('status', 'active')->first();

            if (!isset($checkUserStatus)) {
                return json_encode(array('status' => 2, 'message' => 'Please verify OTP.'));
            }

            $credentials = array('email' => $input['email'], 'password' => $input['password'], 'user_roles_id' => env('USER_ROLE'));

            if (Auth::attempt($credentials, true)) {
                $data['user_id'] = Auth::user()->id;
                $data['name'] = ucfirst(Auth::user()->name);
                $data['email'] = Auth::user()->email;
                $data['address'] = ucwords(Auth::user()->address);
                $data['contact_number'] = Auth::user()->contact_number;
                if(Auth::user()->profile_photo != '') {
                    $data['profile_photo'] = env('PHOTO_URL'). Auth::user()->profile_photo;
                } else {
                    $data['profile_photo'] = env('DEFAULT_PHOTO_URL');
                }

                /* update device token */
                $arr = array('device_token' => $input['device_token']);
                User::where('id', $data['user_id'])->update($arr);

                $ret = array('status' => 1, 'message' => 'Login successfully.', 'data' => $data);
            } else {
                $ret = array('status' => 0, 'message' => 'Wrong email or password.');
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Please fill all field.');
        }

        print_r(json_encode($ret));
    }

    /*
    ** verify otp
    */
    public function verifyOtp(Request $request)
    {
        $otp = $request->get('otp');
        $email = $request->get('email');
        $user = User::where('email', $email)->first();
        if (!isset($user)) {
            return json_encode(array('status' => 0, 'message' => 'Enter registered email.'));
        }

        if ($otp != $user['otp']) {
            return json_encode(array('status' => 0, 'message' => 'OTP not match.'));
        }

        $currentTime = strtotime(date('Y-m-d H:i:s'));
        if ($currentTime > $user['otp_expiry_time']) {
            return json_encode(array('status' => 0, 'message' => 'OTP expired.'));
        }

        /* update user status */
        $arr = array("status" => "active");
        $update = User::where('email', $email)->update($arr);
        if ($update) {
            return json_encode(array('status' => 1, 'message' => 'OTP match. Login your account'));
        }
    }

    /*
   ** verify otp
   */
    public function resendOtp(Request $request)
    {
        $email = $request->get('email');
        $user = User::where('email', $email)->first();
        if (!isset($user)) {
            return json_encode(array('status' => 0, 'message' => 'Enter registered email.'));
        }

        /* OTP */
        $numbers = '0123456789';
        $numbersLength = strlen($numbers);
        $randomNumber = '';
        $length = 4;
        for ($i = 0; $i < $length; $i++) {
            $randomNumber .= $numbers[rand(0, $numbersLength - 1)];
        }

        $currentTime = strtotime(date('Y-m-d H:i:s'));
        $expiryTime = strtotime("+30 minutes", $currentTime);

        $arr = array("otp" => $randomNumber, "otp_expiry_time" => $expiryTime);
        $update = User::where('email', $email)->update($arr);
        if ($update) {
            return json_encode(array('status' => 1, 'message' => 'OTP send on your registered mobile number. Check your sms.'));
        }
    }

    /*
    ** forgot password
    */
    public function forgotPassword(Request $request)
    {
        $input = $request->all();
        $rules = array('email' => 'required');
        $v = Validator::make($input, $rules);
        if ($v->passes()) {
            $email = $input['email'];
            $user = User::where('email', $email)->first();
            if (!isset($user)) {
                return json_encode(array('status' => 0, 'message' => 'Enter registered email.'));
            }

            /* email toekn */
            $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charsLength = strlen($chars);
            $randomString = '';
            $length = 20;

            for ($i = 0; $i < $length; $i++) {
                $randomString .= $chars[rand(0, $charsLength - 1)];
            }
            $currentTime = strtotime(date('Y-m-d H:i:s', time()));
            $expiryTime = $currentTime + 3600;
            /* update token */
            $arr = array("email_token" => $randomString, "token_expiry_time" => $expiryTime);
            User::where('email', $email)->update($arr);

            /* send mail */
            $user = User::where('email', $email)->first();
            $id = Crypt::encrypt($user['id']);
            $link = env('APP_URL') . 'verify-token?token=' . $user['email_token'] . '&uid=' . $id;
            $this->sendForgotPasswordMail($user['name'], $user['email'], $link);
            $ret = array('status' => 1, 'message' => 'Email has successfully sent. Please check your email inbox/spam messages.');
        } else {
            $ret = array('status' => 0, 'message' => 'Email required.');
        }

        return json_encode($ret);
    }

    /*
    ** send forgot password mail
    */
    public function sendForgotPasswordMail($name = NULL, $email = NULL, $link = NULL)
    {
        $to = $email;
        $subject = "Forgot Password - Mohali Home Services";
        $txt = '<p>Hello ' . ucfirst($name) . ',</p>';
        $txt .= '<p>To change your password click on <strong>Click Here</strong>. Your link is expire after 1 hour.</p><br/>';
        $txt .= '<a href="' . $link . '" target="_blank">Click Here</a>';
        $txt .= '<p>Thanks</p>';
        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ritu.itcorporates@gmail.com";

        mail($to, $subject, $txt, $headers);
    }

    /* 
    ** forgot password link
    */
    public function forgotPasswordLink(Request $request)
    {
        $data['page_title'] = 'Mohali Home Services | Forgot Password';
        $data['id'] = $request->input('uid');
        $uid = Crypt::decrypt($data['id']);
        $user = User::find($uid);
        $currentTime = strtotime(date('Y-m-d H:i:s', time()));
        if ($currentTime > $user->token_expiry_time) {
            $request->session()->flash('msg', 'Your link has expired. Please try again.');
        }

        return view('api.forgotPassword', $data);
    }

    /* 
    ** get password
    */
    public function getPassword(Request $request)
    {
        $input = $request->all();
        $id = Crypt::decrypt($input['id']);
        $payload = array('password' => Hash::make($input['password']));
        $update = User::where('id', $id)->update($payload);
        if ($update) {
            return redirect('api/forgotPassword/success');
        }
    }

    /* 
    ** success
    */
    public function successMessage()
    {
        $data['page_title'] = 'Mohali Home Services | Forgot Password | Success';
        return view('api.successMessage', $data);
    }

    /*
    ** booking
    */
    public function booking(Request $request)
    {
        $input = $request->all();
        $v = Validator::make($input, Booking::$rules);
        if ($v->passes()) {
            $booking = new Booking();
            $booking->user_id = $input['user_id'];
            $booking->phone_number = $input['phone_number'];
            $booking->booking_date = strtotime($input['booking_date']);
            $booking->booking_time = strtotime($input['booking_time']);
            $booking->type = $input['type'];
            if ($booking->save()) {
                $user = User::find($booking->user_id);

                $data['booking_id'] = $booking->id;
                $data['type'] = $booking->type;
                $data['customer_name'] = ucfirst($user->name);
                $data['customer_email'] = $user->email;
                $data['customer_phone'] = $booking->phone_number;
                $data['booking_date'] = date('D d, M, Y', $booking->booking_date);
                $data['booking_time'] = date('h:i:s a', $booking->booking_time);

                $ret = array('status' => 1, 'message' => '' . ucfirst($booking->type) . ' successfully booked.', 'data' => $data);
            } else {
                $ret = array('status' => 0, 'message' => 'Booking Failed.');
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Please fill all field.');
        }
        print_r(json_encode($ret));
    }

    /*
    ** get bookings by user id
    */
    public function getBookingById(Request $request)
    {
        $res = array();
        $userid = $request->get('user_id');
        if (isset($userid)) {
            $bookings = Booking::where('user_id', $userid)->orderBy('id', 'desc')->get();
            if(isset($bookings)) {
                foreach ($bookings as $booking) {
                    $user = User::find($booking['user_id']);

                    $data['booking_id'] = $booking['id'];
                    $data['type'] = $booking['type'];
                    $data['customer_name'] = ucfirst($user->name);
                    $data['customer_email'] = $user->email;
                    $data['customer_phone'] = $booking['phone_number'];
                    $data['booking_date'] = date('D d, M, Y', $booking['booking_date']);
                    $data['booking_time'] = date('h:i:s a', $booking['booking_time']);
                    $data['job_status'] = $booking['job_status'];
                    $data['invoice'] = $booking['is_invoice'];
                    $res[] = $data;
                }
                $ret = array('status' => 1, 'message' => 'Booking History.', 'data' => $res);
            } else {
                $ret = array('status' => 0, 'message' => 'Booking not found.');
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Missing parameter user_id');
        }

        print_r(json_encode($ret));
    }

    /*
    **cancel booking
    */
    public function cancelBooking(Request $request) {
        $input = $request->all();
        if(isset($input)) {
            if(isset($input['user_id']) && isset($input['booking_id'])) {
                $update = array('job_status' => 'cancelled');
                $booking = Booking::where('id', $input['booking_id'])
                    ->where('user_id', $input['user_id'])->update($update);

                if($booking == true) {
                    $ret = array('status' => 1, 'message' => 'Order has been cancelled with order id '.$input['booking_id'].'.');
                } else {
                    $ret = array('status' => 0, 'message' => 'Oops, Something went wrong.');
                }
            } else {
                $ret = array('status' => 0, 'message' => 'Missing parameters');
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Missing parameters');
        }

        print_r(json_encode($ret));
    }

    /*
    ** Edit user profile
    */
    public function editProfile(Request $request) {
        if($request->get('user_id')) {
            $id = $request->get('user_id');
            $user =User::find($id);
            if($request->get('name')) {
                $name = $request->get('name');
            } else {
                $name = $user->name;
            }

            if($request->get('email')) {
                $email = $request->get('email');
            } else {
                $email = $user->email;
            }

            if($request->get('phone')) {
                $phone = $request->get('phone');
            } else {
                $phone = $user->contact_number;
            }

            if($request->get('address')) {
                $address = $request->get('address');
            } else {
                $address = $user->address;
            }

            $update = array('name' => $name,
                'email' => $email,
                'contact_number' => $phone,
                'address' => $address);

            User::where('id',$id)->update($update);

            if ($request->file('profile_photo')) {
                unlink("./public/uploads/".$user->profile_photo);

                $file = $request->file('profile_photo');
                $name = $request->get('name').'_'.rand() . '.' . $file->getClientOriginalExtension();
                $file->move('./public/uploads', $name);
                $arr = array('profile_photo' => $name);
                User::where('id',$id)->update($arr);
            }

            $user =User::find($id);
            $data['user_id'] = $user->id;
            $data['name'] = ucfirst($user->name);
            $data['email'] = $user->email;
            $data['address'] = ucwords($user->address);
            $data['contact_number'] = $user->contact_number;
            $data['profile_photo'] = env('PHOTO_URL').$user->profile_photo;

            $ret = array('status' => 1, 'message' => 'Profile updated successfully','data'=>$data);
        }  else {
            $ret = array('status' => 0, 'message' => 'Missing parameter user_id');
        }

        print_r(json_encode($ret));
    }

    /*
    ** provider login
    */
    public function providerPostSignin(Request $request) {
        $input = $request->all();
        $rules = array('email' => 'required', 'password' => 'required', 'device_token' => 'required');
        $v = Validator::make($input, $rules);
        if ($v->passes()) {
            if($input['profession'] == 'Plumber') {
                $credentials = array('email' => $input['email'], 'password' => $input['password'], 'user_roles_id' => env('PLUMBER_ROLE'));
            } elseif($input['profession'] == 'Electrician') {
                $credentials = array('email' => $input['email'], 'password' => $input['password'], 'user_roles_id' => env('ELECTRICIAN_ROLE'));
            } elseif($input['profession'] == 'Tank Cleaner') {
                $credentials = array('email' => $input['email'], 'password' => $input['password'], 'user_roles_id' => env('TANK_CLEANER_ROLE'));
            } elseif($input['profession'] == 'Painter') {
                $credentials = array('email' => $input['email'], 'password' => $input['password'], 'user_roles_id' => env('PAINTER_ROLE'));
            } else {
                return json_encode(array('status' => 0, 'message' => 'Wrong email or password.'));
            }

            if (Auth::attempt($credentials, true)) {
                $userRole = User_Role::find(Auth::user()->user_roles_id);
                $data['user_id'] = Auth::user()->id;
                $data['profession'] = $userRole->name;
                $data['name'] = ucfirst(Auth::user()->name);
                $data['email'] = Auth::user()->email;
                $data['address'] = ucwords(Auth::user()->address);
                $data['contact_number'] = Auth::user()->contact_number;
                if(Auth::user()->profile_photo != '') {
                    $data['profile_photo'] = env('PHOTO_URL'). Auth::user()->profile_photo;
                } else {
                    $data['profile_photo'] = env('DEFAULT_PHOTO_URL');
                }

                /* update device token */
                $arr = array('device_token' => $input['device_token']);
                User::where('id', $data['user_id'])->update($arr);

                $ret = array('status' => 1, 'message' => 'Login successfully.', 'data' => $data);
            } else {
                $ret = array('status' => 0, 'message' => 'Wrong email or password.');
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Please fill all field.');
        }

        print_r(json_encode($ret));
    }

    /*
    ** To do list
    */
    public function todoList(Request $request) {
        $res = array();
        $type = $request->get('profession');
        if(isset($type)) {
            $bookings = Booking::where('type', $type)->get();
            if(isset($bookings)) {
                foreach ($bookings as $booking) {
                    $date = date('M jS, Y', $booking['booking_date']);
                    $time = date('h:i:s a', $booking['booking_time']);
                    $booking_date = $date.', '.$time;

                    $user = User::find($booking['user_id']);
                    $customer_address = ucfirst($user->name).', '.$booking['phone_number'].', '.ucWords($user->address);


                    $data['booking_id'] = $booking['id'];
                    $data['booking_date'] = $booking_date;
                    $data['customer_detail'] = $customer_address;
                    $data['job_status'] = $booking['job_status'];
                    $res[] = $data;
                }
                $ret = array('status' => 1, 'message' => 'Tasks List', 'data' => $res);
            } else {
                $ret = array('status' => 1, 'message' => 'Empty list found.', 'data' => $res);
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Missing parameter profession');
        }

        print_r(json_encode($ret));
    }

    /*
    ** tasks approval
    */
    public function taskApproval(Request $request) {
        $input = $request->all();
        if(isset($input)) {
            $rules = array('booking_id' => 'required', 'latitude' => 'required', 'longitude' => 'required');
            $v = Validator::make($input, $rules);
            if ($v->passes()) {
                $provider_lat = $input['latitude'];
                $provider_lng = $input['longitude'];

                $booking = Booking::find($input['booking_id']);
                $user = User::find($booking->user_id);
                $address = $user->address;

                /* get customer lat long form address */
                $url = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBUcIApnoBk4aLtzr4P3zWBeEKqun0oGzU&address='.urlencode($address));
                $result = json_decode($url);
                if(isset($result)) {
                    $user_lat = $result->results[0]->geometry->location->lat;
                    $user_lng = $result->results[0]->geometry->location->lng;
                } else {
                    $user_lat = 0;
                    $user_lng = 0;
                }

                /* distance */
                $theta = $user_lng - $provider_lng;
                $dist = sin(deg2rad($user_lat)) * sin(deg2rad($provider_lat)) +  cos(deg2rad($user_lat)) * cos(deg2rad($provider_lat)) * cos(deg2rad($theta));
                $dist = acos($dist);
                $dist = rad2deg($dist);
                $miles = $dist * 60 * 1.1515;
                $distance = round($miles * 1.609344).' km';

                $update = array("distance" => $distance,
                                "latitude" => $provider_lat,
                                "longitude" => $provider_lng,
                                "job_status" => "approved");
                Booking::where('id', $input['booking_id'])->update($update);

                $booking = Booking::find($input['booking_id']);
                $data['job_status'] = $booking->job_status;
                $data['distance'] = $booking->distance;

                $ret = array('status' => 1, 'message' => 'Task Approved.', 'data' => $data);
            } else {
                $ret = array('status' => 0, 'message' => 'Missing parameters');
            }
        } else {
            $ret = array('status' => 0, 'message' => 'Missing parameters');
        }

        print_r(json_encode($ret));
    }
}