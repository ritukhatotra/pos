<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function test() {
        echo "Hello";
    }

    /*
    ** get all products
    */
    public function index() {
        return Product::all();
    }

    /*
    ** get product by id
    */
    public function show(Product $product) {
        return $product;
    }

    /*
    ** save product
    */
    public function save(Request $request) {
        $product = Product::create($request->all());
        return response()->json($product, 201);
    }

    /*
    ** update product
    */
    public function update(Request $request, Product $product) {
        $product->update($request->all());
        return response()->json($product, 200);
    }

    /*
    ** delete product
    */
    public function delete(Product $product) {
        $product->delete();
        return response()->json(null, 204);
    }
}