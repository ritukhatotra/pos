<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $table = 'bookings';
    protected $fillable = array('user_id','alternate_phone_number','booking_date','booking_time','type','job_status','is_invoice','created_at','updated_at');

    public static $rules = array("user_id" => "required",
                                "phone_number" => "required",
                                "booking_date" => "required",
                                "booking_time" => "required",
                                "type" => "required"
                        );

    /*
    ** Get the users.
    */
    public function users()
    {
        return $this->hasMany('App\User');
    }
}